
MCMC.import <- function(param, init, data, sd=NULL,R=100,thin=20,warmup=5000,ll="pois", llEpid=NULL, nchains=3) {
  # change to put ahead in the parameters of sampler
  
    if (length(init)!=8 | length(sd)!=8) stop("init and SD must be a list with 8 parameters (r,T0,r2,Tcp2,r3,Tcp3,k,s)")
    npar=8;
 
  if (ll=="pois"){
    type=1
    print("computing poisson likelihood for submission")
  } else if (ll=="nb"){
    type=2
    print("computing NB likelihood for submission")
  }else if (ll=="pois.cond"){
    type=3
    print("computing conditional poisson likelihood for submission")
  }  else if (ll=="nb.cond"){
    type=4
    print("computing conditional NB likelihood for submission")
  } else if (ll=="nb2"){
    type=5
    print("computing NB likelihood type 2 for submission")
  } else if (ll=="nb2.cond"){
    type=6
    print("computing conditional NB likelihood type 2 for submission")
  }else if (ll=="pois.auto"){
    type=7
    print("computing pois likelihood for submission with autochtonous cases")
  }else if (ll=="pois.auto.cond"){
    type=8
    print("computing conditional pois likelihood for submission with autochtonous cases")
  }else if (ll=="nb.auto"){
    type=9
    print("computing conditional NB likelihood for submission with autochtonous cases")
  } else {
    stop("unknown option")
  }
  
  if (is.null(llEpid)) {
    typeEpid=0
    print("no likelihood for UK epid")
  } else  if (llEpid=="pois") {
    typeEpid=1    
    print("pois likelihood for UK epid")
  } else if (llEpid=="nb") {
    typeEpid=2
    print("nb likelihood for UK epid")
  }
  
  
  cluster <- parallel::makeCluster(nchains)
  doParallel::registerDoParallel(cluster)
  
  seeds =1:nchains
  doPar=rep(0,npar)
  lW = data$lW
  
  resAll <- foreach::foreach (chain=seeds, .packages=c("importFromUK","coda")) %dopar% {
    set.seed(as.numeric(Sys.time())+chain)
    
    # param : parameters for optimisation; list
    # init 0 for all parameters
    initPar=rep(0,npar)
    initPar[1]=init$r
    if("r" %in% param) {doPar[1]=1; dim_r=1;print(paste0("chain ",chain,": optimizing r"))} else {print(paste("chain ",chain,": r fixed at ",init$r))}
    
    initPar[2]=init$T0
    if("T0" %in% param) {doPar[2]=1;   print(paste0("chain ",chain,": optimizing T0 between ", format(data$date.start) ,"and ",format(data$date.start+data$T0.max)))} else {print(paste("chain ",chain,": T0 fixed at ",init$T0))}
    
    initPar[3]=init$r2
    if("r2" %in% param) {
      dim_r=2
      doPar[3]=1; print(paste("chain ",chain,": optimizing r2")); 
      initPar[4]=init$Tcp2;
      
      if ("T2" %in% param) {
        doPar[4]=1;
        print(paste0("chain ",chain,": optimizing T2 between ",as.Date("2020-10-15")," and ", as.Date("2020-12-15")));
      } else {
        print(paste0("chain ",chain," set Tcp2 to ",init$Tcp2));
      }
    } else {
      initPar[3]= NA
      initPar[4] = lW # set Tcp2 to lW
      print(paste0("chain ",chain,": r2 not used. Set to NA"))
    }
    
    initPar[5]=init$r3
    if("r3" %in% param) {
      doPar[5]=1; dim_r=3; print(paste0("chain ",chain,": optimizing r3")); 
      initPar[6]=init$Tcp3;
      print(paste0("chain ",chain,": set Tcp3 to ",init$Tcp3));
    } else {
      initPar[5]= NA
      initPar[6] = lW # set Tcp3 to lW
      print(paste0("chain ",chain,": r3 not used. Set to NA"))
    }
    
    initPar[7]=init$k
    if("k" %in% param) {doPar[7]=1;print(paste0("chain",chain,": optimizing k"))} else {print(paste0("chain ",chain,": k fixed at ",init$k))}
    
    
      initPar[8]=init$s
      if("s" %in% param) {doPar[8]=1;print(paste0("chain",chain,": optimizing s"))} else {print(paste0("chain ",chain,": s fixed at ",init$s))}
      sd = as.vector(c(sd$r,sd$T0,sd$r2,sd$Tcp2,sd$r3,sd$Tcp3,sd$k,sd$s))

      
      res=sampler(type, R, thin, warmup, doPar,initPar, dim_r,
                  data$lW, data$ahead, data$incub, data$nCountry, 
                  data$Ts, data$Ti.lo, data$Ti.up, data$delta1,
                  data$tKp, data$s, data$dt.s.increase, data$iUK-1,
                  data$delai.array, 
                  data$p.over.R, data$r,
                  typeEpid, data$epidUK, data$t0Epid,
                  sd, data$T0.max,chain);
      
      res$res = matrix( res$res,ncol=12)
      colnames(res$res)=c("r","T0","r2","Tcp2","r3","Tcp3","k","s","logL","logLEpid","logPrior", "lp__")
      names(res$accept)=c("r","T0","r2","Tcp2","r3","Tcp3","k","s")

    if (dim_r<2) res$res[,"r2"]=res$res[,"r"]
    if (dim_r<3) res$res[,"r3"]=res$res[,"r2"]
    resMCMC = coda::mcmc(res$res)
    
    
    attr(resMCMC,"accept")=res$accept
    resMCMC
  }  
  parallel::stopCluster(cluster)
  # transformation of mcmc
  resAll <- list(mcmc=coda::as.mcmc.list(resAll))
  resAll$metadata <- list(ll=ll, 
                          type=type, 
                          llEpid=llEpid,
                          typeEpid=typeEpid,
                          date.thr=data$date.thr, 
                          date.start=data$date.start,
                          date.compute=date(),
                          data=data)
  #resAll is a 
  return(resAll)
}

