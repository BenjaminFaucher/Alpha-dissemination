
compute.DIC <- function(summa,data) {
  # take the values from a summary
  # take the values and remove the dexp for r,r2,r3
  mean.logV = mean(summa$res$logL)
  mean.logVEpid= mean(summa$res$logLEpid)
  
  mean.par = apply(summa$res[,c("r","T0","r2","Tcp2","r3","Tcp3","k","s")],2,mean)
  #note rho1, s on the log scale should be averaged
  mean.par=as.list(mean.par)
  mean.par$s=exp(mean(log(summa$res$s)))
  mean.par$r2 = mean.par$r * exp(mean(log(summa$res$r2/summa$res$r)))
  
  logL_cur=NA
  logPrior_cur=NA
  
  ll=summa$metadata$ll
  
  if (ll=="pois"){
    logL = logL_1sub_pois
    conditional=0
    print("computing poisson likelihood for submission")
  } else if (ll=="nb"){
    logL = logL_1sub_nb
    conditional=0
    print("computing NB likelihood for submission")
  }else if (ll=="pois.cond"){
    logL = logL_1sub_pois
    conditional=1
    type=3
    print("computing conditional poisson likelihood for submission")
  }  else if (ll=="nb.cond"){
    logL = logL_1sub_nb
    conditional=1
    type=4
    print("computing conditional NB likelihood for submission")
  } else if (ll=="nb2"){
    logL = logL_1sub_nb2
    conditional=0
    type=5
    print("computing NB likelihood type 2 for submission")
  } else if (ll=="nb2.cond"){
    logL = logL_1sub_nb2
    conditional=1
    type=6
    print("computing conditional NB likelihood type 2 for submission")
  }else if (ll=="pois.auto"){
    logL = logL_1sub_auto_pois
    conditional=0
    type=7
    print("computing pois likelihood for submission with autochtonous cases")
  }else if (ll=="pois.auto.cond"){
    logL = logL_1sub_auto_pois
    conditional=1
    type=8
    print("computing conditional pois likelihood for submission with autochtonous cases")
  } else {
    stop("unknown logLikelihood")
  }
  
  llEpid = summa$metadata$llEpid
  if (is.null(llEpid)) {
    typeEpid=0
    logLEpid=function(...) {return(0)}
    print("no likelihood for UK epid")
  } else  if (llEpid=="pois") {
    typeEpid=1    
    logLEpid=logL_epid_pois
    print("pois likelihood for UK epid")
  } else if (llEpid=="nb") {
    typeEpid=2
    logLEpid=logL_epid_nb
    print("nb likelihood for UK epid")
  }
  
  logV.mean = logL(c(mean.par$r,mean.par$r2,mean.par$r3), 
                   floor(c(mean.par$T0,mean.par$Tcp2,mean.par$Tcp3)), 
                   mean.par$k, mean.par$s,
                   data$lW, data$ahead, data$incub, data$nCountry,
                   data$Ts, data$Ti.lo,data$Ti.up, data$delta1,
                   data$tKp, data$s, data$dt.s.increase, data$iUK,
                   data$delai.array,
                   data$p.over.R, data$r,
                   conditional)
  
  logV.Epid.mean = logLEpid(c(mean.par$r,mean.par$r2,mean.par$r3), 
                            floor(c(mean.par$T0,mean.par$Tcp2,mean.par$Tcp3)), 
                            mean.par$k,data$lW, data$epidUK, data$t0Epid)
  
  DIC.intro = -2*2*mean.logV + 2 * (logV.mean)
  DIC.epid = -2*2*mean.logVEpid + 2 * (logV.Epid.mean)
  DIC = -2*2*(mean.logV+mean.logVEpid) + 2 * (logV.mean+logV.Epid.mean)
  c(DIC=DIC, intro=DIC.intro,epid=DIC.epid)
  
}

