prep.data.dynamic = function(VOC, date.thr, pop.uk=36E6, dt.sub=T, before=F) {
  
  # columns are expected to start at 1 with "date.ref" (date.ref -> column 1)
  
  ref.date= as.Date("2020-08-15")
  # first we count dates from 2020-08-0=15
  VOC$dt.col.lo = as.numeric(VOC$date.collection.lo - ref.date)+1
  VOC$dt.col.up = as.numeric(VOC$date.collection.up - ref.date)+1
  VOC$dt.sub = as.numeric(VOC$date.submission - ref.date)+1
  # date of first submission
  VOC$dt.1sub = as.numeric(VOC$date.1st.sub - ref.date)+1
  
  
  VOC$Ts =as.numeric(date.thr - ref.date)+1
  VOC$Ts[!is.na(VOC$date.submission) & (VOC$date.submission < date.thr) ] = 
    VOC$dt.sub[!is.na(VOC$date.submission) & (VOC$date.submission < date.thr) ]
  #those unobserved are set to 
  # then we compute indicator of censoring
  VOC$delta1=0
  # exact dates
  if (dt.sub == TRUE) { dt.cond = VOC$date.submission}
  else if (dt.sub == FALSE) { dt.cond =VOC$date.collection}
  
  # on met delta1=1 si soumission avant dt.thr
  VOC$delta1[!is.na(dt.cond) & (dt.cond <= date.thr)] = 1
  
  if (before == FALSE) {
  } else {
  }
  # We prob number per day
  VOC[,grep("p.",names(VOC),fixed=T)] = VOC[,grep("p.",names(VOC),fixed=T)]/pop.uk
  VOC[VOC$country=="United Kingdom",grep("p.",names(VOC),fixed=T)]=1
  
  #  VOC$Ts=VOC$dt.sub
  #  VOC$Ts[is.na(VOC$Ts)]=as.numeric(date.thr - ref.date)+1
  #  VOC$Ts[VOC$delta1==0] = as.numeric(date.thr - ref.date)+1
  
  VOC$Ti.lo=VOC$dt.col.lo
  VOC$Ti.lo[VOC$delta1==0]=as.numeric(date.thr - ref.date)+1
  
  VOC$Ti.up=VOC$dt.col.up
  VOC$Ti.up[VOC$delta1==0]=as.numeric(date.thr - ref.date)+2
  
  
  VOC
}

make.data.dynamic = function(first.VOC, screen, travel, date.thr, epidUK, freq.screening=NULL, min.freq=0,
                             delai.sub1=NULL,delai.sub2=NULL,date.change=as.Date("2020-12-18"),
                             index.country=NULL,pop.uk=38e6, M=NULL,R=NULL, r=NULL, 
                             R.increase=0,K=0.5,K.UK=0.4,dt.sub=T, 
                             before=F,countries=NULL, s.increase=1, 
                             dt.s.increase=NULL, incub=4,
                             truncate=FALSE,T0.max=NULL,
                             date.ref=as.Date("2020-08-15"),
                             ahead=7, dt.start.epid=NULL, dt.stop.epid=NULL) {
  
  # add ahead to make projections, keeping tKps and delai and p 
  # add epidUK and t0Epid
  
  VOC=merge(first.VOC,screen,by=0, all.y=T)
  VOC$Row.names=NULL
  VOC= merge(VOC,travel,by="country", all.x=T)
  
  # days are numbered from 2020/01/01 as "%j",  "d.XXX" - in sequecing, in delai
  index.date.start=as.numeric(format(date.ref,"%j"))
  index.date.change=as.numeric(format(date.change,"%j"))
  # weeks are numbered from 2020/01/01, as "%V", "p.XX" in travel data
  index.week.start=as.numeric(format(date.ref,"%V"))
  
  
  if (is.null(dt.start.epid)) {dt.start.epid = min(epidUK$day); print (paste("setting epid start date to", dt.start.epid))}
  if (is.null(dt.stop.epid)) {dt.stop.epid = min(max(epidUK$day),date.thr) ; print (paste("setting epid stop date to", dt.stop.epid))}
  if (dt.start.epid < min(epidUK$day)) {dt.start.epid = min(epidUK$day); print (paste("changing epid start date to", dt.start.epid))}
  if (dt.stop.epid > min(max(epidUK$day),date.thr)) {dt.stop.epid = min(max(epidUK$day),date.thr); print (paste("changing epid stop date to", dt.stop.epid))}
  epidUK = epidUK[(epidUK$day <=date.thr) &(epidUK$day>=dt.start.epid) &(epidUK$day<=dt.stop.epid),]
  t0Epid=as.numeric(format(min(epidUK$day),"%j")) - index.date.start+1
  epidUK=epidUK$VOCcases
  
  
  # delai is date.sub - date.col +1 // computed elsewhere
  
  VOC[VOC$country=="United Kingdom",grep("p.",names(VOC),fixed=T)]=0
  
  VOC = VOC[!is.na(VOC[,paste("p.",index.week.start,sep="")]),]
  
  if (!is.null(countries)) {
    VOC = VOC[VOC$country %in% countries,]
  } 
  countries=as.character(VOC$country)
  
  
  # here we compute the dates of the travel weeks.
  # data starts with the first week of August : 2020-08-03, so p.1 is for this week
  # we extend the data from August 1st then delete unnecessary columns
  
  # nombre de jours
  seq.days =seq(date.ref,date.thr+ahead,1) 
  lW= length(seq.days)-ahead
  #days weeks
  # correspondance avec les semaines pour le travel
  # this compute the week numbers
  # when goes to 1
  weeks = as.numeric(format(seq.days,"%V"))
  # if there are weeks before index.week.start, add 53 because 53 weeks in 2020
  weeks[weeks < index.week.start] = 53 + weeks[weeks < index.week.start]
  
  W=weeks
  
  if (!is.null(freq.screening)) {
    VOC = merge(VOC,freq.screening,by="country")
    VOC = VOC[VOC$freq>=min.freq,]
    countries=as.character(VOC$country)
  }
  
  
  if (!is.null(R)) {
    #extract days
    R = R[,c("country",paste("R",seq(index.date.start,length.out=lW+ahead,by=1),sep="."))]
    names(R) = c("country",paste("R",seq(1,length.out=lW+ahead,by=1),sep="."))
    VOC = merge(VOC,R, by="country",all.x=T)
    if (any(is.na(VOC$R.1))) stop("not all countries have R")
    VOC[VOC$country=="United Kingdom",grep("R.",names(VOC),fixed=T)]=0
  }
  
  if (!is.null(r)) {
    r = r[,c("country",paste("r",seq(index.date.start,length.out=lW+ahead,by=1),sep="."))]
    names(r) = c("country",paste("log.r",seq(1,length.out=lW+ahead,by=1),sep="."))
    VOC = merge(VOC,r, by="country",all.x=T)
    if (any(is.na(VOC$r.1))) stop("not all countries have r")
    VOC[VOC$country=="United Kingdom",grep("log.r.",names(VOC),fixed=T)]=0
  }
  
  if (!is.null(countries)) {
    VOC = VOC[VOC$country %in% countries,]
  }
  
  VOC.prep = prep.data.dynamic(VOC = VOC, 
                               date.thr = as.Date(date.thr,origin="1970-01-01"), 
                               pop.uk = pop.uk,
                               dt.sub = dt.sub, before=before)
  
  
  
  if (truncate==TRUE) {
    VOC.prep = VOC.prep[VOC.prep$delta1==1,]
  }
  
  if (!is.null(delai.sub1)) { 
    delai.sub1 = delai.sub1[VOC$country] 
  }
  if (!is.null(delai.sub2)) { 
    delai.sub2 = delai.sub2[VOC$country] 
  }
  
  if (!is.null(delai.sub1) && is.null(delai.sub2)) { 
    for (i in 1:length(delai.sub1)) {
      # select from date start to lW
      row.col.names = paste("d",index.date.start:(index.date.start+lW+ahead-1),sep=".")
      delai.sub1[[i]] = delai.sub1[[i]][row.col.names,row.col.names]
    }
    delai.sub = delai.sub1
  }
  
  
  if (!is.null(delai.sub1) && !is.null(delai.sub2)) {
    delai.sub = delai.sub1
    for (i in 1:length(delai.sub1)) {
      # select from date start to lW
      col.names = paste("d",index.date.start:(index.date.start+lW+ahead-1),sep=".")
      row.names.1 = paste("d",index.date.start:(index.date.change-1),sep=".")
      row.names.2 = paste("d",index.date.change:(index.date.start+lW+ahead-1),sep=".")
      delai.sub1[[i]] = delai.sub1[[i]][row.names.1,col.names]
      delai.sub2[[i]] = delai.sub2[[i]][row.names.2,col.names]
      delai.sub[[i]] = rbind(delai.sub1[[i]],delai.sub2[[i]])
    }
  }
  
  
  delai.sub = delai.sub[VOC.prep$country] 
  
  nCountry=length(VOC.prep$country)
  # verifier l'ordre des delais
  #make an array of this :
  delai.sub.array=array(NA,c(lW+ahead,lW+ahead,nCountry))
  for (i in 1:nCountry) {
    delai.sub.array[,,i] = delai.sub[[i]]
  }
  
  if (is.null(M)) {M = length(W)} 
  M = rep(1,times=M)
  
  # screening 
  s=as.matrix(VOC.prep[,paste0("s.",seq(index.date.start,length.out=lW+ahead,by=1))])
  # rename to 1:lW
  colnames(s) = paste0("s.",1:(lW+ahead))
  #  s=as.matrix(VOC.prep[,paste0("s.",1:length(W))])
  
  rownames(s)=VOC.prep$country
  
  colnames(s)=NULL
  
  s.orig=s
  #s.orig[s.orig>1]=1
  # increase testing in travellers // all but not the UK
  if (!is.null(dt.s.increase)) {
    dt.s.increase = as.numeric(dt.s.increase-date.ref)+1
    s[-which(VOC.prep$country=="United Kingdom"),dt.s.increase:length(s[1,])]=  
      s[-which(VOC.prep$country=="United Kingdom"),dt.s.increase:length(s[1,])] * s.increase
    s[s>1]=1 
  } else {
    dt.s.increase=lW+ahead
    s.increase=1
  }
  
  #expand p to dates
  p=VOC.prep[,paste0("p.",weeks)]
  rownames(p) = VOC.prep$country
  
  #T0.max can be a few days before first collection in the UK
  if(is.null(T0.max)) {
    T0.max=VOC.prep$Ti.lo[VOC.prep$country=="United Kingdom"]-1
  } else {
    T0.max=VOC.prep$Ti.lo[VOC.prep$country=="United Kingdom"]-T0.max
  }
  
  Kps = K*p*s
  Kps[which(VOC.prep$country=="United Kingdom"),] = K.UK/K *  Kps[which(VOC.prep$country=="United Kingdom"),]
  tKps=t(Kps)
  colnames(tKps)=rownames(s)
  
  # o use in estimating s
  Kp = K*p
  Kp[which(VOC.prep$country=="United Kingdom"),] = K.UK/K *  Kp[which(VOC.prep$country=="United Kingdom"),]
  tKp=t(Kp)
  colnames(tKp)=rownames(s)
  
  # to test
  iUK = which(VOC.prep$country=="United Kingdom")
  iFR = which(VOC.prep$country=="France")
  
  
  data=list(country = VOC.prep$country,
            nCountry=length(VOC.prep$country), 
            nWeeks=max(W),
            lW=lW,
            ahead=ahead,
            T=VOC.prep$T,
            probD=VOC.prep$prob,
            s=s.orig,
            p=p,
            tKps=tKps,
            tKp=tKp,
            W=W,
            delta1=VOC.prep$delta1,
            K=K,
            M=M,
            d=delai.sub,# delais
            incub=incub,
            dt.s.increase=dt.s.increase,
            s.increase=s.increase, 
            K=K, 
            K.UK=K.UK,
            T0.max=T0.max,
            Ts=VOC.prep$Ts,
            Ti.lo=VOC.prep$Ti.lo,
            Ti.up=VOC.prep$Ti.up,
            date.start=date.ref,
            date.thr=date.thr,
            delai.array=delai.sub.array,
            epidUK=epidUK,
            t0Epid=t0Epid,
            iUK=iUK,
            iFR=iFR
  )
  
  if (!is.null(R)) {
    # if R<1, probability of survival is 0
    # if R>1, probabuility of survival is 1-1/R
    # this is probability of having offspring when entering 
    R=as.matrix(VOC.prep[,paste0("R.",1:(lW+ahead))])
    R=R[,1:(lW+ahead)]*(1+R.increase)
    R[R<1]=0
    #R=R[-which(VOC.prep$country=="United Kingdom"),]
    colnames(R)=NULL
    data$R=R
    data$p.over.R = data$p*(1-1/data$R)
    data$p.over.R = as.matrix(data$p.over.R)
    data$p.over.R[is.infinite(data$p.over.R)]=0
    data$p.over.R[is.na(data$p.over.R)]=0
    data$p.over.R[data$p.over.R<0]=0
    colnames(data$p.over.R)=NULL
    data$p.over.R=t(data$p.over.R)
  }
  
  if (!is.null(r)) {
    #this is the log-expected multiplication of cases
    r=as.matrix(VOC.prep[,paste0("log.r.",1:(lW+ahead))])
    r=r[,1:(lW+ahead)]
    r=r + log((1+R.increase))/7
    r.preComp = array(0,dim = c((lW+ahead),(lW+ahead),data$nCountry))
    for (i in 1:data$nCountry) {
      for (j in 2:lW) {
        r.preComp[ (j:(lW+ahead))-1,j-1,i] = exp(cumsum(r[i,j:(lW+ahead)]))      
      }
      r.preComp[,,i]=t(r.preComp[,,i])
    }
    data$r=r.preComp
  }
  
  data
}

