summary.MCMC.import = function(res,data,burnin=1/2,sample=2000,computeAutoEpid=0) {
  #ahead is lead time for prediction
  #res may be a list of several results
  if(is.null(res$res)) {
    # res may contain a coda mcmc.list
    if (!is.null(res$mcmc)) {
      # make a big sample
      df.res = nlist::collapse_chains(res$mcmc)[[1]]
      df.res=df.res[,c("r","T0","r2","Tcp2","r3","Tcp3","k","s","logL","logLEpid","logPrior","lp__")]
    } else {
      # is a list : rbind columns
      df.res=NULL
      nChains=length(res)
      for (i in 1:length(res)) {
        df.res=rbind(df.res,res[[i]]$res)
      }
    }
    R = dim(df.res)[1]
  } else {
    R = dim(res$res)[1]
    df.res = res$res
  }
  print(paste("using ",R," iterations"))
  
  if (all(df.res[,"r"] == df.res[,"r2"])) {dim_r=1}
  else if (all(df.res[,"r2"] == df.res[,"r3"])) {dim_r=2}
  else {dim_r=3}

    if (is.null(data$p.over.R) | is.null(data$r)) {computeAutoEpid=0}

      Fdistr = calc_F_country(df.res,R,data$lW,data$ahead,data$nCountry,dim_r,data$incub, 
                            data$Ts, data$delta1,
                            as.matrix(data$p), 
                            data$tKp, data$s, data$dt.s.increase, data$iUK,
                            data$delai.array, 
                            data$p.over.R, data$r,
                            computeAutoEpid)

  #Fdistr is lW+ahead
  df.res=as.data.frame(df.res)
  
  df.res$t2=log(2)/df.res$r
  df.res$t2.2=log(2)/(df.res$r2)
  df.res$t2.3=log(2)/(df.res$r3)
  
  df.res$dt.T0=data$date.start + df.res$T0
  df.res$dt.Tcp2=data$date.start + df.res$Tcp2
  df.res$dt.Tcp3=data$date.start + df.res$Tcp3
  
  df.res$model="import"
  
  fitSub= data.frame(day=data$date.start-1+1:length(Fdistr$all.sub$mean), 
                     #                     mean=apply(Fdistr$submitted$mean,1,sum),
                     mean=Fdistr$all.sub$mean,
                     #                     med=apply(Fdistr$submitted$med,1,sum),
                     med=Fdistr$all.sub$med,
                     #                     lo=apply(Fdistr$submitted$lo,1,sum),
                     lo=Fdistr$all.sub$lo,
                     #                     up=apply(Fdistr$submitted$up,1,sum),
                     up=Fdistr$all.sub$up,
                     type="model",
                     value="submitted")
  
  fitCol= data.frame(day=data$date.start-1+1:length(Fdistr$all.col$mean), 
                     #                     mean=apply(Fdistr$collected$mean,1,sum),
                     #                     med=apply(Fdistr$collected$med,1,sum),
                     #                     lo=apply(Fdistr$collected$lo,1,sum),
                     #                     up=apply(Fdistr$collected$up,1,sum),
                     mean=Fdistr$all.col$mean,
                     med=Fdistr$all.col$med,
                     lo=Fdistr$all.col$lo,
                     up=Fdistr$all.col$up,
                     type="model",
                     value="collected")
  
  fitColSub= data.frame(day=data$date.start-1+1:length(Fdistr$col.sub$mean), 
                        #                     mean=apply(Fdistr$collected$mean,1,sum),
                        #                     med=apply(Fdistr$collected$med,1,sum),
                        #                     lo=apply(Fdistr$collected$lo,1,sum),
                        #                     up=apply(Fdistr$collected$up,1,sum),
                        mean=Fdistr$col.sub$mean,
                        med=Fdistr$col.sub$med,
                        lo=Fdistr$col.sub$lo,
                        up=Fdistr$col.sub$up,
                        type="model",
                        value="coll+sub")
  
  cumSubObs = summary(survival::survfit(survival::Surv(data$Ts, data$delta1)~1), times=(0:data$lW),extend=T)
  #  cumSubObs = (ecdf(data$Ts)(1:data$lW))*data$nCountry
  
  cumSubObs = data.frame(day=data$date.start-1 + 1:(data$lW+1),
                         surv=(1-cumSubObs$surv)*data$nCountry,
                         lo=(1-cumSubObs$lower)*data$nCountry,
                         up=(1-cumSubObs$upper)*data$nCountry,
                         type="observed",
                         value="submitted")
  
  cumColObs = summary(survival::survfit(survival::Surv(data$Ti.lo,data$Ti.up, 3*data$delta1,type='interval')~1), times=(0:data$lW),extend=T)
  #  cumColObs = (ecdf(data$Ti)(1:data$lW))*data$nCountry
  
  cumColObs = data.frame(day=data$date.start-1 + 1:(data$lW+1),
                         surv=(1-cumColObs$surv)*data$nCountry,
                         lo=(1-cumColObs$lower)*data$nCountry,
                         up=(1-cumColObs$upper)*data$nCountry,
                         type="observed",
                         value="collected")
  
  fitModel=rbind(fitSub,fitCol,fitColSub)
  fitObs = rbind(cumSubObs,cumColObs)
  Fdistr$country = data$country
  
  return(list(res=df.res, distr=Fdistr, model=fitModel, observed=fitObs, 
              metadata=res$metadata,date.compute=date()))
}
