#include <Rcpp.h>

using namespace Rcpp;
using namespace std;

double norm_rs(double a, double b)
{
  double  x;
  x = R::norm_rand();
  while( (x < a) || (x > b) ) x = R::norm_rand();
  return x;
}

double half_norm_rs(double a, double b)
{
  double   x;
  x = fabs(R::norm_rand());
  while( (x<a) || (x>b) ) x = fabs(R::norm_rand());
  return x;
}

double unif_rs(double a, double b)
{
  double xstar, logphixstar, x, logu;

  // Find the argmax (b is always >= 0)
  // This works because we want to sample from N(0,1)
  if(a <= 0.0) xstar = 0.0;
  else xstar = a;
  logphixstar = R::dnorm(xstar, 0.0, 1.0, 1.0);

  x = R::runif(a, b);
  logu = log(R::runif(0.0, 1.0));
  while( logu > (R::dnorm(x, 0.0, 1.0,1.0) - logphixstar))
  {
    x = R::runif(a, b);
    logu = log(R::runif(0.0, 1.0));
  }
  return x;
}

double exp_rs(double a, double b)
{
  double  z, u, rate;

  //  Rprintf("in exp_rs");
  rate = 1/a;
  //1/a

  // Generate a proposal on (0, b-a)
  z = R::rexp(rate);
  while(z > (b-a)) z = R::rexp(rate);
  u = R::runif(0.0, 1.0);

  while( log(u) > (-0.5*z*z))
  {
    z = R::rexp(rate);
    while(z > (b-a)) z = R::rexp(rate);
    u = R::runif(0.0,1.0);
  }
  return(z+a);
}

// [[Rcpp::export]]
double rnorm_trunc (double mu, double sigma, double lower, double upper)
{
  int change;
  double a, b;
  double logt1 = log(0.150), logt2 = log(2.18), t3 = 0.725;
  double z, tmp, lograt;

  change = 0;
  a = (lower - mu)/sigma;
  b = (upper - mu)/sigma;

  // First scenario
  if( (a == R_NegInf) || (b == R_PosInf))
  {
    if(a == R_NegInf)
    {
      change = 1;
      a = -b;
      b = R_PosInf;
    }

    // The two possibilities for this scenario
    if(a <= 0.45) z = norm_rs(a, b);
    else z = exp_rs(a, b);
    if(change) z = -z;
  }
  // Second scenario
  else if((a * b) <= 0.0)
  {
    // The two possibilities for this scenario
    if((R::dnorm(a, 0.0, 1.0,1.0) <= logt1) || (R::dnorm(b, 0.0, 1.0, 1.0) <= logt1))
    {
      z = norm_rs(a, b);
    }
    else z = unif_rs(a,b);
  }
  // Third scenario
  else
  {
    if(b < 0)
    {
      tmp = b; b = -a; a = -tmp; change = 1;
    }

    lograt = R::dnorm(a, 0.0, 1.0, 1.0) - R::dnorm(b, 0.0, 1.0, 1.0);
    if(lograt <= logt2) z = unif_rs(a,b);
    else if((lograt > logt1) && (a < t3)) z = half_norm_rs(a,b);
    else z = exp_rs(a,b);
    if(change) z = -z;
  }
  double output;
  output = sigma*z + mu;
  return (output);
}


double compute_logL_1sub_pois(double r0, double r1, double r2, int T0, int T1, int T2, double dispersion,
                              double s_increase,
                              int dim_r,
                      int lW, int ahead, int incub, int nCountry,
                      IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                      NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                      NumericVector delai_sub,
                      NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                      int conditional) {

  double target=0.0;
  int lW_ahead = lW+ahead;

//  Rcout<<target<<"\n";

  NumericVector exp_r_t(lW);
  for (int t=0; t < T0; t++) {
    //allow
    exp_r_t[t]=f_before_T0 * exp(r0 * (t-T0));
  }
  for (int t=T0; t < T1; t++) {
    exp_r_t[t]=exp(r0 * (t-T0));
  }
  for (int t=T1; t < T2; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) +  r1*(t-T1));
  }
  for (int t=T2; t < lW; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
  }
  NumericVector exp_r_t_travel(lW);

  for(int u=0; u<incub; u++){
    for (int t=0; t+u <lW; t++){
      exp_r_t_travel[t+u] += exp_r_t[t];
    }
  }

  // on remplit maintenant avec s_increase
  //  Rcout << "screening 0\nc(";
  //for (int t=0; t<lW_ahead; t++) Rcout << sMod[0 + t*nCountry]<<",";
  //Rcout<<")\n";

  //Rcout << "screening UK\nc(";
  //for (int t=0; t<lW_ahead; t++) Rcout << sMod[iUK + t*nCountry]<<",";
  //Rcout<<")\n";

  //int iFR=21;
  //Rcout << "screening FR\nc(";
  //for (int t=0; t<lW_ahead; t++) Rcout << sMod[iFR + t*nCountry]<<",";
  //Rcout<<")\n";

//  Rcout << "exp_r_t_travel: c(";
//  for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
//  Rcout<<")\n";

  NumericMatrix lambda(lW,nCountry);

  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      if ((t >= dt_s_increase) && (i != iUK)) {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry]*s_increase,1.0) * exp_r_t_travel[t];
      } else {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry],1.0) * exp_r_t_travel[t];
      }
    }
//    if ((i==7) || (i==iFR) || (i ==iUK)) {
//        Rcout << "country " <<i<< " lambda: c(";
//          for (int t=0; t<lW; t++) Rcout << lambda[t]<<",";
//        Rcout<<")\n";
//    }
  }


  int lWSquared=lW_ahead*lW_ahead;
  NumericMatrix xi(lW,lW);
  NumericVector phi(lW);

  for (int i=0; i<nCountry; i++) {
//    Rcout <<"target "<<target<<"\n";
//    Rcout <<"country "<<i<<"\n";
    for(int t=0; t<lW; t++) {
      phi[t]=0.0;
      for(int u=0; u<=t; u++) {
        xi[u+t*lW] = delai_sub[u + t*lW_ahead + i*lWSquared] * lambda[u+i*lW]; //xi(t,u)
        phi[t] += xi[u+t*lW];
      }
    }
//    Rcout << "xi(u,t): c(";
//    for (int t=0; t<lW; t++) {
//      for (int u=0; u<lW; u++) {Rcout << xi[u+t*lW]<<",";}
//      Rcout <<"\n";
//    }
//    Rcout<<")\n";
  //  Rcout << "phi(t): c(";
//    for (int t=0; t<lW; t++) Rcout << phi[t]<<",";
//    Rcout<<")\n";
    double E_N_T0_Ts = 0.0;
    // this is E(N_1+...N_Ts)
    for (int t=0; t<Ts[i]; t++) E_N_T0_Ts += phi[t];
//    target +=  R::dpois(0,E_N_T0_Ts,true);
// P(N_t=0) = exp(- phi[t])
      target -= E_N_T0_Ts;  // P(N1=0, ..., NTs=0)
//      Rcout << "E_N_T0_TS: " <<E_N_T0_Ts<<"\n";
    if (delta1[i] == 1) {
//      target -= R::dpois(0,phi[Ts[i]-1],true);
// remove log(P(N(Ts=0))) = +phi[Ts[i]-1]
        target += phi[Ts[i]-1]; // remove P(NTs=0)
//      Rcout << "phi["<<Ts[i]-1<<"] " <<phi[Ts[i]-1]<<"\n";
//      double PNTsgt0 = 1.0 - R::dpois(0,lambda_t[Ts[i]-1],false);
// add in log(1-P(N(Ts=0)))
        double PNTsgt0= -expm1(-phi[Ts[i]-1]); // P(NTs>0) = 1 -exp(-phi(Ts))
      if (PNTsgt0>0.0) {
        target +=  log (PNTsgt0);
//        Rcout << "P(NTs>0) : " << PNTsgt0 << "\n";
      } else {
        Rcerr << "problem with country " << i << " r :" << r0<< " T0 :"<<T0<<" r2: "<<r1<< " r3:"<<r2;
      }
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      double P_Ti = 0.0;
      for (int Ti=Ti_lo[i]-1; Ti<Ti_up[i]-1;Ti++) {
        P_Ti += xi[Ti+lW*(Ts[i]-1)];
      }
      target += log(P_Ti) - log(phi[Ts[i]-1]);
//      Rcout << "P("<<Ti_lo[i]-1<<"<=Ti<"<<Ti_up[i]-1<<"|Ts="<<Ts[i]-1<<") : " << P_Ti <<"/"<<phi[Ts[i]-1] << "\n";
    }
    if (conditional==true) {
      double E_N_T0_T = E_N_T0_Ts;
      for (int t=Ts[i]; t<lW; t++) E_N_T0_T += phi[t];
      // conditional : 1-P(N_T=0)
      target -= log(-expm1(-E_N_T0_T));
    }
  }
//    Rcout<<"target "<<target<<"\n";
  return(target);
}


double compute_logL_1sub_nb(double r0, double r1, double r2, int T0, int T1, int T2, double dispersion, double s_increase,
                            int dim_r,
                 int lW, int ahead, int incub, int nCountry,
                 IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                 NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                 NumericVector delai_sub,
                 NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                 int conditional) {
  // same as above but uses neg binom sampling
  // NB distribution is parametrized with mean, var=mean+mean^2/k
  // therefore 
  
  double target=0.0;
  int lW_ahead = lW+ahead;

  NumericVector exp_r_t(lW);
  for (int t=0; t < T0; t++) {
    exp_r_t[t]= f_before_T0 * exp(r0 * (t-T0));
  }
  for (int t=T0; t < T1; t++) {
    exp_r_t[t]=exp(r0 * (t-T0));
  }
  for (int t=T1; t < T2; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) +  r1*(t-T1));
  }
  for (int t=T2; t < lW; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
  }

  NumericVector exp_r_t_travel(lW);

  for(int u=0; u<incub; u++){
    for (int t=0; t+u <lW; t++){
      exp_r_t_travel[t+u] += exp_r_t[t];
    }
  }

  //  for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
  //  Rcout<<")\n";

  NumericMatrix lambda(lW,nCountry);
  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      if ((t >= dt_s_increase) && (i != iUK)) {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry]*s_increase,1.0) * exp_r_t_travel[t];
      } else {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry],1.0) * exp_r_t_travel[t];
      }
    }
  }
  int lWSquared=lW_ahead*lW_ahead;
  NumericMatrix xi(lW,lW);
  NumericVector phi(lW);

  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      phi[t]=0.0;
      for(int u=0; u<=t; u++) {
        xi[u+t*lW] = delai_sub[u + t*lW_ahead + i*lWSquared] * lambda[u+i*lW]; //xi(t,u)
        phi[t] += xi[u+t*lW];
      }
    }

    // this is computed always : logP(N_T0=0, N_Ts=0)
    double log_P_N_T0_Ts_0 = 0.0;
    for (int t=0; t<Ts[i];t++) {
      for (int u=0; u<= t; u++) {
        if (xi[u+t*lW]>0.0) {
          // P(N_t,u=0) = (1 + xi[] / dispersion)^(-dispersion)
          double tmp =  -dispersion * log1p(xi[u+t*lW]/dispersion);
          log_P_N_T0_Ts_0 += tmp;
        }
      }
    }
    target += log_P_N_T0_Ts_0; // start here for logV

    if (delta1[i] == 1) {
      // remove log P(N_Ts=0), add log(P(N_Ts>0))
      double log_P_N_Ts_0=0.0;
      for (int u=0; u< Ts[i]; u++) {
        if (xi[u+(Ts[i]-1)*lW]>0.0) {
          log_P_N_Ts_0 -=  dispersion * log1p(xi[u+(Ts[i]-1)*lW]/dispersion);
        }
      }
      //remove sum log P(N(Ts,Ti=u)=0
      target -= log_P_N_Ts_0;
      double PNTSgt0=0.0;
            //      double lC = 1.0 - prod R::dbinom(0,mu=lambda_t_u,false);
      PNTSgt0= -expm1(log_P_N_Ts_0); //P(N_Ts>0)= 1-exp(-log_prob0)) // this is 1 - P(all0) = P(at least one >0)
      if (PNTSgt0 >0.0) {
        target +=  log (PNTSgt0);
      } else {
        Rcerr << "problem with country " << i << " r :" << r0<< " T0 :"<<T0<<" r2: "<<r1<< " r3:"<<r2;
      }
      // for NB, probability of (0/1/0) is different from Poisson
      // it is    m[i]/(m[i]+dispersion) / sum_j m[j]/(m[j]+dispersion)
      // this is close to Poisson for big dispersion
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      double P_Ti = 0.0;
      for (int Ti=Ti_lo[i]-1; Ti<Ti_up[i]-1;Ti++) {
        P_Ti += xi[Ti+lW*(Ts[i]-1)];
      }
      target += log(P_Ti) - log(phi[Ts[i]-1]);
      //    
    }
    if (conditional==true) {// conditional (Ts <T)  -
      double log_P_N_T0_T_0=log_P_N_T0_Ts_0;
      for (int t=Ts[i]; t<lW;t++) {
        for (int u=0; u<= t; u++) {
          if (xi[u+t*lW]>0.0) {
            log_P_N_T0_T_0 -= dispersion * log1p(xi[u+t*lW]/dispersion);
          }
        }
      }
      target -= log(-expm1(log_P_N_T0_T_0));
    }
  }
  return(target);
}



double compute_logL_1sub_nb2(double r0, double r1, double r2,
                             int T0, int T1, int T2, double dispersion, double s_increase,
                              int dim_r,
                              int lW, int ahead, int incub, int nCountry,
                              IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                              NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                              NumericVector delai_sub,
                              NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                              int conditional) {
  //uses NB sampling, but on each day (not day/delay)
  double target=0.0;
  int lW_ahead = lW + ahead;

  NumericVector exp_r_t(lW);
  for (int t=0; t < T0; t++) {
    exp_r_t[t]=f_before_T0 * exp(r0 * (t-T0));
  }
  for (int t=T0; t < T1; t++) {
    exp_r_t[t]=exp(r0 * (t-T0));
  }
  for (int t=T1; t < T2; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) +  r1*(t-T1));
  }
  for (int t=T2; t < lW; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
  }

  NumericVector exp_r_t_travel(lW);

  for(int u=0; u<incub; u++){
    for (int t=0; t+u <lW; t++){
      exp_r_t_travel[t+u] += exp_r_t[t];
    }
  }

  //  Rcout << "exp_r_t_travel: c(";
  //  for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
  //  Rcout<<")\n";

  //  Rcout << "exp_r_t_travel: c(";
  //  for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
  //  Rcout<<")\n";

  NumericMatrix lambda(lW,nCountry);
  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      if ((t >= dt_s_increase) && (i != iUK)) {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry]*s_increase,1.0) * exp_r_t_travel[t];
      } else {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry],1.0) * exp_r_t_travel[t];
      }
    }
  }

  //  Rcout << "lambda: c(";
  //  for (int t=0; t<lW; t++) Rcout << lambda[t]<<",";
  //  Rcout<<")\n";

  int lWSquared=lW_ahead*lW_ahead;
  NumericMatrix xi(lW,lW);
  NumericVector phi(lW);

  for (int i=0; i<nCountry; i++) {
    //Rcout << "country : " << i <<"\n";
    for(int t=0; t<lW; t++) {
      phi[t]=0.0;
      for(int u=0; u<=t; u++) {
        xi[u+t*lW] = delai_sub[u + t*lW_ahead + i*lWSquared] * lambda[u+i*lW]; //xi(t,u)
        phi[t] += xi[u+t*lW];
      }
    }

    //    Rcout << "xi(u,t): c(";
    //    for (int t=0; t<lW; t++) {
    //      for (int u=0; u<lW; u++) {Rcout << xi[u+t*lW]<<",";}
    //      Rcout <<"\n";
    //    }
    //    Rcout<<")\n";

    //    Rcout << "phi(t): c(";
    //    for (int t=0; t<lW; t++) Rcout << phi[t]<<",";
    //    Rcout<<")\n";

    double log_P_N_T0_Ts_0 = 0.0;
    // this is E(N_1+...N_Ts)
    for (int t=0; t<Ts[i]; t++) {
// in the NB, P(Nt=0) = (k/(m+k))^k, so -k*log(1+m/k) = -k*log1p(m/k)
      double tmp= -dispersion * log1p(phi[t]/dispersion);// P(N1=0, ..., NTs=0)
      log_P_N_T0_Ts_0 += tmp;
    }
    // log P(NT0,..., NTs=0)=0)
    target += log_P_N_T0_Ts_0;
    //Rcout << "P_N_T0_TS: " <<exp(log_P_N_T0_Ts_0)<<"\n";
    if (delta1[i] == 1) {
      //      target -= R::dpois(0,phi[Ts[i]-1],true);
      // remove log P(NTs=0)
      target += dispersion * log1p(phi[Ts[i]-1]/dispersion);
      //      Rcout << "phi["<<Ts[i]-1<<"] " <<phi[Ts[i]-1]<<"\n";
      // P(NTs>0)
      double PNTsgt0= -expm1(-dispersion*log1p(phi[Ts[i]-1]/dispersion));
      if (PNTsgt0>0.0) {
        target +=  log (PNTsgt0);
      //        Rcout << "P(NTs>0) : " << PNTsgt0 << "\n";
      } else {
        Rcerr << "problem with country " << i << " r :" << r0<< " T0 :"<<T0<<" r2: "<<r1<< " r3:"<<r2;
      }

      // for NB, probability of (0/1/0) is different from Poisson
      // it is    m[i]/(m[i]+dispersion) / sum_j m[j]/(m[j]+dispersion)
      // this is close to Poisson for big dispersion
      // for this formulation of NB, no exact calculation is possible,
      // since we do not have divisibility...
      // so we go for POISSON instead
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      double P_Ti = 0.0;
      for (int Ti=Ti_lo[i]-1; Ti<Ti_up[i]-1;Ti++) {
        P_Ti += xi[Ti+lW*(Ts[i]-1)];
      }
      target += log(P_Ti) - log(phi[Ts[i]-1]);
      //      Rcout << "P(Ti="<<Ti[i]-1<<"|Ts="<<Ts[i]-1<<") : " << xi[(Ti[i]-1)+lW*(Ts[i]-1)] <<"/"<<phi[Ts[i]-1] << "\n";
    }
    if (conditional==true) {
      double log_P_N_T0_T_0=log_P_N_T0_Ts_0;
      for (int t=Ts[i]; t<lW; t++) {
        log_P_N_T0_T_0 += phi[t];
      }
      target -= log1p(-log_P_N_T0_T_0);
    }
  }
  return(target);
}


double compute_logL_1sub_auto_pois(double r0, double r1, double r2, int T0, int T1, int T2, double dispersion,double s_increase,
                                   int dim_r,
                                   int lW, int ahead, int incub, int nCountry,
                                   IntegerVector Ts, IntegerVector Ti_lo, IntegerVector Ti_up, IntegerVector delta1,
                                   NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                                   NumericVector delai_sub,
                                   NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                                   int conditional) {

  // add autochtonous transmission : compute transmission from cases that are admitted
  // take all those getting admitted (i.e. before sequenced)
  // compute cases from this on
  double target=0.0;
  int lW_ahead = lW+ahead;

  NumericVector exp_r_t(lW);
  for (int t=0; t < T0; t++) {
    exp_r_t[t]=f_before_T0 * exp(r0 * (t-T0));
  }
  for (int t=T0; t < T1; t++) {
    exp_r_t[t]=exp(r0 * (t-T0));
  }
  for (int t=T1; t < T2; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) +  r1*(t-T1));
  }
  for (int t=T2; t < lW; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
  }

  NumericVector exp_r_t_travel(lW);

  for(int u=0; u<incub; u++){
    for (int t=0; t+u <lW; t++){
      exp_r_t_travel[t+u] += exp_r_t[t];
    }
  }
  // this is entering country


//    Rcout << "exp_r_t_travel: c(";
//    for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
//    Rcout<<")\n";


  NumericMatrix lambda(lW,nCountry); //intensity of incoming
  NumericMatrix lambda_auto(lW,nCountry); //
  NumericMatrix alpha(lW,nCountry); // cumulated number of autochtonous cases + imported
  
  int lWSquared=lW_ahead*lW_ahead;


  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      if ((t >= dt_s_increase) && (i != iUK)) {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry]*s_increase,1.0) * exp_r_t_travel[t];
      } else {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry],1.0) * exp_r_t_travel[t];
      }
      //number having offspring
      lambda_auto[t+i*lW] = p_over_R[t+i*lW_ahead] * exp_r_t_travel[t];
      alpha[t+i*lW]=0.0;
      for(int u=0; u<t; u++) {
//        if ((i==0) & (t==70)) {
//          Rcout <<"t "<<t<< " u " << u << " "<<lambda_auto[u] << " * " << cum_growth_rate[u + t*lW + i *lWSquared] << "\n";
//        }
        alpha[t+i*lW] += lambda_auto[u+i*lW] * cum_growth_rate[u + t*lW_ahead + i*lWSquared];
      }
      //Rcout << i << " " << t <<"\n";
    }
  }

//  Rcout << "lambda: c(";
//  for (int t=0; t<lW; t++) Rcout << lambda[t]<<",";
//  Rcout<<")\n";

//  Rcout << "lambda_auto: c(";
//  for (int t=0; t<lW; t++) Rcout << lambda_auto[t]<<",";
//  Rcout<<")\n";

//  Rcout << "alpha: c(";
//  for (int t=0; t<lW; t++) Rcout << alpha[t]<<",";
//  Rcout<<")\n";

//  Rcout << "r(u,t): c(";
//  for (int t=0; t<lW; t++) {
//    for (int u=0; u<lW; u++) {Rcout << cum_growth_rate[u+t*lW]<<",";}
//    Rcout <<"\n";
//  }
//  Rcout<<")\n";

  NumericMatrix xi(lW,lW);
  NumericVector phi(lW);
  //xi are sequenced + submitted
  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      phi[t]=0.0;
      for(int u=0; u<=t; u++) {
        xi[u+t*lW] = delai_sub[u + t*lW_ahead + i*lWSquared] * (lambda[u+i*lW] + alpha[u+i*lW]); //xi(t,u)
        phi[t] += xi[u+t*lW];
      }
    }

    //    Rcout << "xi(u,t): c(";
    //    for (int t=0; t<lW; t++) {
    //      for (int u=0; u<lW; u++) {Rcout << xi[u+t*lW]<<",";}
    //      Rcout <<"\n";
    //    }
    //    Rcout<<")\n";

    //    Rcout << "phi(t): c(";
    //    for (int t=0; t<lW; t++) Rcout << phi[t]<<",";
    //    Rcout<<")\n";

    double E_N_T0_Ts = 0.0;
    // this is E(N_1+...N_Ts)
    for (int t=0; t<Ts[i]; t++) E_N_T0_Ts += phi[t];

    //    target +=  R::dpois(0,E_N_T0_Ts,true);
    //    target +=  R::dpois(0,E_N_T0_Ts,true);
    target -= E_N_T0_Ts;  // P(N1=0, ..., NTs=0)
    //      Rcout << "E_N_T0_TS: " <<E_N_T0_Ts<<"\n";
    if (delta1[i] == 1) {
      //      target -= R::dpois(0,phi[Ts[i]-1],true);
      target += phi[Ts[i]-1]; // remove P(NTs=0)
      //      Rcout << "phi["<<Ts[i]-1<<"] " <<phi[Ts[i]-1]<<"\n";

      //      double lC = 1.0 - R::dpois(0,lambda_t[Ts[i]-1],false);
      double PNTsgt0= -expm1(-phi[Ts[i]-1]); // P(NTs>0)
      if (PNTsgt0>0.0) {
        target +=  log (PNTsgt0);
        //        Rcout << "P(NTs>0) : " << lC << "\n";
      } else {
        Rcerr << "problem with country " << i << " r :" << r0<< " T0 :"<<T0<<" r2: "<<r1<< " r3:"<<r2;
      }
      //P(Ti=Ti | Ts=Ts)
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      double P_Ti = 0.0;
      for (int Ti=Ti_lo[i]-1; Ti<Ti_up[i]-1;Ti++) {
        P_Ti += xi[Ti+lW*(Ts[i]-1)];
      }
      target += log(P_Ti) - log(phi[Ts[i]-1]);
      //      Rcout << "P(Ti="<<Ti[i]-1<<"|Ts="<<Ts[i]-1<<") : " << xi[(Ti[i]-1)+lW*(Ts[i]-1)] <<"/"<<phi[Ts[i]-1] << "\n";
    }
    if (conditional == true) {
      double E_N_T0_T = E_N_T0_Ts;
      // this is E(N_1+...N_T)
      for (int t=Ts[i]; t<lW; t++) E_N_T0_T += phi[t];
      target -= log(-expm1(-E_N_T0_T));
    }
  }
    return(target);
}


double compute_logL_1sub_auto_nb(double r0, double r1, double r2, int T0, int T1, int T2, double dispersion,double s_increase,
                                   int dim_r,
                                   int lW, int ahead, int incub, int nCountry,
                                   IntegerVector Ts, IntegerVector Ti_lo, IntegerVector Ti_up, IntegerVector delta1,
                                   NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                                   NumericVector delai_sub,
                                   NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                                   int conditional) {
  
  // add autochtonous transmission : compute transmission from cases that are admitted
  // take all those getting admitted (i.e. before sequenced)
  // compute cases from this on
  double target=0.0;
  int lW_ahead = lW+ahead;
  
  NumericVector exp_r_t(lW);
  for (int t=0; t < T0; t++) {
    exp_r_t[t]=f_before_T0 * exp(r0 * (t-T0));
  }
  for (int t=T0; t < T1; t++) {
    exp_r_t[t]=exp(r0 * (t-T0));
  }
  for (int t=T1; t < T2; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) +  r1*(t-T1));
  }
  for (int t=T2; t < lW; t++) {
    exp_r_t[t]=exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
  }
  
  NumericVector exp_r_t_travel(lW);
  
  for(int u=0; u<incub; u++){
    for (int t=0; t+u <lW; t++){
      exp_r_t_travel[t+u] += exp_r_t[t];
    }
  }
  // this is entering country
  
  
  //    Rcout << "exp_r_t_travel: c(";
  //    for (int t=0; t<lW; t++) Rcout << exp_r_t_travel[t]<<",";
  //    Rcout<<")\n";
  
  
  NumericMatrix lambda(lW,nCountry); //intensity of incoming
  NumericMatrix lambda_auto(lW,nCountry); //
  NumericMatrix alpha(lW,nCountry); // cumulated number of autochtonous cases + imported
  
  int lWSquared=lW_ahead*lW_ahead;
  
  
  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      if ((t >= dt_s_increase) && (i != iUK)) {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry]*s_increase,1.0) * exp_r_t_travel[t];
      } else {
        lambda[t+i*lW] = tKp[t+i*lW_ahead] * min(s[i + t*nCountry],1.0) * exp_r_t_travel[t];
      }
      //number having offspring
      lambda_auto[t+i*lW] = p_over_R[t+i*lW_ahead] * exp_r_t_travel[t];
      alpha[t+i*lW]=0.0;
      for(int u=0; u<t; u++) {
        //        if ((i==0) & (t==70)) {
        //          Rcout <<"t "<<t<< " u " << u << " "<<lambda_auto[u] << " * " << cum_growth_rate[u + t*lW + i *lWSquared] << "\n";
        //        }
        alpha[t+i*lW] += lambda_auto[u+i*lW] * cum_growth_rate[u + t*lW_ahead + i*lWSquared];
      }
      //Rcout << i << " " << t <<"\n";
    }
  }
  
  //  Rcout << "lambda: c(";
  //  for (int t=0; t<lW; t++) Rcout << lambda[t]<<",";
  //  Rcout<<")\n";
  
  //  Rcout << "lambda_auto: c(";
  //  for (int t=0; t<lW; t++) Rcout << lambda_auto[t]<<",";
  //  Rcout<<")\n";
  
  //  Rcout << "alpha: c(";
  //  for (int t=0; t<lW; t++) Rcout << alpha[t]<<",";
  //  Rcout<<")\n";
  
  //  Rcout << "r(u,t): c(";
  //  for (int t=0; t<lW; t++) {
  //    for (int u=0; u<lW; u++) {Rcout << cum_growth_rate[u+t*lW]<<",";}
  //    Rcout <<"\n";
  //  }
  //  Rcout<<")\n";
  
  NumericMatrix xi(lW,lW);
  NumericVector phi(lW);
  //xi are sequenced + submitted
  for (int i=0; i<nCountry; i++) {
    for(int t=0; t<lW; t++) {
      phi[t]=0.0;
      for(int u=0; u<=t; u++) {
        xi[u+t*lW] = delai_sub[u + t*lW_ahead + i*lWSquared] * (lambda[u+i*lW] + alpha[u+i*lW]); //xi(t,u)
        phi[t] += xi[u+t*lW];
      }
    }
    
    //    Rcout << "xi(u,t): c(";
    //    for (int t=0; t<lW; t++) {
    //      for (int u=0; u<lW; u++) {Rcout << xi[u+t*lW]<<",";}
    //      Rcout <<"\n";
    //    }
    //    Rcout<<")\n";
    
    //    Rcout << "phi(t): c(";
    //    for (int t=0; t<lW; t++) Rcout << phi[t]<<",";
    //    Rcout<<")\n";
    
    double log_P_N_T0_Ts_0 = 0.0;
    // this is E(N_1+...N_Ts)
    for (int t=0; t<Ts[i]; t++) {
      // in the NB, P(Nt=0) = (k/(m+k))^k, so -k*log(1+m/k) = -k*log1p(m/k)
      double tmp= -dispersion * log1p(phi[t]/dispersion);// P(N1=0, ..., NTs=0)
      log_P_N_T0_Ts_0 += tmp;
    }
    // log P(NT0,..., NTs=0)=0)
    target += log_P_N_T0_Ts_0;
    //Rcout << "P_N_T0_TS: " <<exp(log_P_N_T0_Ts_0)<<"\n";
    if (delta1[i] == 1) {
      //      target -= R::dpois(0,phi[Ts[i]-1],true);
      // remove log P(NTs=0)
      target += dispersion * log1p(phi[Ts[i]-1]/dispersion);
      //      Rcout << "phi["<<Ts[i]-1<<"] " <<phi[Ts[i]-1]<<"\n";
      // P(NTs>0)
      double PNTsgt0= -expm1(-dispersion*log1p(phi[Ts[i]-1]/dispersion));
      if (PNTsgt0>0.0) {
        target +=  log (PNTsgt0);
        //        Rcout << "P(NTs>0) : " << PNTsgt0 << "\n";
      } else {
        Rcerr << "problem with country " << i << " r :" << r0<< " T0 :"<<T0<<" r2: "<<r1<< " r3:"<<r2;
      }
      //P(Ti=Ti | Ts=Ts)
      //P(Ti_lo <=Ti<Ti_up | Ts=Ts)
      double P_Ti = 0.0;
      for (int Ti=Ti_lo[i]-1; Ti<Ti_up[i]-1;Ti++) {
        P_Ti += xi[Ti+lW*(Ts[i]-1)];
      }
      target += log(P_Ti) - log(phi[Ts[i]-1]);
      //      Rcout << "P(Ti="<<Ti[i]-1<<"|Ts="<<Ts[i]-1<<") : " << xi[(Ti[i]-1)+lW*(Ts[i]-1)] <<"/"<<phi[Ts[i]-1] << "\n";
    }
    
    if (conditional==true) {// conditional (Ts <T)  -
      double log_P_N_T0_T_0=log_P_N_T0_Ts_0;
      for (int t=Ts[i]; t<lW;t++) {
        for (int u=0; u<= t; u++) {
          if (xi[u+t*lW]>0.0) {
            log_P_N_T0_T_0 -= dispersion * log1p(xi[u+t*lW]/dispersion);
          } 
        }
      }
      target -= log(-expm1(log_P_N_T0_T_0));
    }
  }
  return(target);
}


// [[Rcpp::export]]
double compute_logL_epid_pois(double r0_cur, double r1_cur, int T0_cur, int T1_cur, double dispersion,
                         NumericVector epidUK, int t0Epid, int durEpid, double lfSumEpid, NumericVector lfEpid){

  // compute expected profile, then compute Multinomial
  NumericVector incid(durEpid);
  double sumIncid=0;
  for (int t=0; t < durEpid; t++) {
    if (t0Epid + t <= T1_cur ) {
      incid[t] = exp(r0_cur * (t));
    } else if (t0Epid + t > T1_cur) {
      // after the change
      incid[t] = exp(r0_cur*(T1_cur-t0Epid) + r1_cur*(t-T1_cur));
    }
    sumIncid += incid[t] ;
  }
  //compute profile
  incid = incid /sumIncid;

   // this is a constant; can be computed once
  //double logL= -sumlFactorial + sum(-incid);
  double logL= lfSumEpid;
  for (int t=0; t < durEpid; t++) logL+= epidUK[t] * log(incid[t]) - lfEpid[t];

  return(logL);
}


// [[Rcpp::export]]
double compute_logL_epid_nb(double r0_cur, double r1_cur, int T0_cur, int T1_cur, double dispersion,
                            NumericVector epidUK, int t0Epid, int durEpid, double lfSumEpid, NumericVector lfEpid){

  // compute expected profile, then compute NB distance to observed
  NumericVector incid(durEpid);
  double sumIncid=0;
  for (int t=0; t < durEpid; t++) {
    if (t0Epid + t <= T1_cur ) {
      incid[t] = exp(r0_cur * (t));
    } else if (t0Epid + t > T1_cur) {
      // after the change
      incid[t] = exp(r0_cur*(T1_cur-t0Epid) + r1_cur*(t-T1_cur));
    }
    sumIncid += incid[t] ;
  }
  //compue profile
  incid = incid /sumIncid;

  // this is a constant; can be computed once
//  double logL= -sumlFactorial;
  double logL=lfSumEpid;
  for (int t=0; t < durEpid; t++) logL+= epidUK[t] * log(incid[t]) - lfEpid[t];

  return(logL);
}

// [[Rcpp::export]]
double logL_1sub_pois(NumericVector r, IntegerVector T, double dispersion, double s_increase,
                      int lW, int ahead, int incub, int nCountry,
                      IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                      NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                      NumericVector delai_sub,
                      NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                      int conditional) {

  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }
  double logL=compute_logL_1sub_pois(r0,r1,r2,T0,T1,T2,dispersion,s_increase,dim_r,lW,ahead,incub,nCountry,Ts,Ti_lo,Ti_up,delta1,tKp,s,dt_s_increase,iUK,delai_sub,p_over_R,cum_growth_rate, f_before_T0,conditional);
  return(logL);
}


// [[Rcpp::export]]
double logL_1sub_nb(NumericVector r, IntegerVector T, double dispersion, double s_increase,
                      int lW, int ahead, int incub, int nCountry,
                      IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                      NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                      NumericVector delai_sub,
                      NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                      int conditional) {

  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }

  double logL=compute_logL_1sub_nb(r0,r1,r2,T0,T1,T2,dispersion,s_increase,
                                   dim_r,lW,ahead,incub,nCountry,
                                   Ts,Ti_lo,Ti_up,delta1,
                                   tKp,s,dt_s_increase,iUK,
                                   delai_sub,
                                   p_over_R,cum_growth_rate,
                                   f_before_T0,conditional );
  return(logL);
}


// [[Rcpp::export]]
double logL_1sub_nb2(NumericVector r, IntegerVector T, double dispersion,double s_increase,
                    int lW, int ahead,int incub, int nCountry,
                    IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                    NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                    NumericVector delai_sub,
                    NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                    int conditional) {

  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }

  double logL=compute_logL_1sub_nb2(r0,r1,r2,
                                    T0,T1,T2,
                                    dispersion,s_increase,
                                    dim_r,lW,ahead,incub,nCountry,
                                    Ts,Ti_lo,Ti_up,delta1,
                                    tKp,s,dt_s_increase,
                                    iUK,delai_sub,
                                    p_over_R,cum_growth_rate,
                                    f_before_T0, conditional 
                                    );
  return(logL);
}

// [[Rcpp::export]]
double logL_1sub_auto_pois(NumericVector r, IntegerVector T, double dispersion, double s_increase,
                           int lW, int ahead, int incub, int nCountry,
                           IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up,IntegerVector delta1,
                           NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                           NumericVector delai_sub,
                           NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
                           int conditional) {

  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }

  double logL=compute_logL_1sub_auto_pois(r0,r1,r2,T0,T1,T2,dispersion,s_increase,dim_r,lW,ahead,incub,nCountry,Ts,Ti_lo,Ti_up,delta1,tKp,s,dt_s_increase,iUK,delai_sub,p_over_R,cum_growth_rate, f_before_T0, conditional);
  return(logL);
}


// [[Rcpp::export]]
double logL_epid_pois(NumericVector r, IntegerVector T, double dispersion, int lW,
                      NumericVector epidUK, int t0Epid){

  //computations
  int durEpid = epidUK.size();
  NumericVector tmp(1);
  tmp[0]=sum(epidUK);
  tmp = lfactorial(tmp);
  double lfSumEpid= tmp[0];

  NumericVector lfEpid = lfactorial(epidUK);


  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }

  double logL = compute_logL_epid_pois(r0, r1, T0, T1, dispersion, epidUK, t0Epid, durEpid, lfSumEpid, lfEpid);
  return(logL);
}


// [[Rcpp::export]]
double logL_epid_nb(NumericVector r, IntegerVector T, double dispersion, int lW,
                    NumericVector epidUK, int t0Epid){

  int durEpid = epidUK.size();
  NumericVector tmp(1);
  tmp[0]=sum(epidUK);
  tmp = lfactorial(tmp);
  double lfSumEpid= tmp[0];

  NumericVector lfEpid = lfactorial(epidUK);

  int dim_r=r.size();
  double r0=r[0];
  double r1=r[0];
  double r2=r[0];

  int T0 = T[0];
  int T1 = lW;
  int T2 = lW;

  if (dim_r>1) {
    r1=r[1];
    T1=T[1];
  }
  if (dim_r>2) {
    r2=r[2];
    T2 = T[2];
  }

  double logL = compute_logL_epid_nb(r0, r1, T0, T1, dispersion, epidUK, t0Epid, durEpid, lfSumEpid, lfEpid);
  return(logL);
}

double compute_priors(int do_r0,int do_r1, int do_r2, int do_k, int do_s,
                 double r0, double rho1, double r2, double k, double log_s) {
  double sum_priors=0.0;
  // add priors : exponential(0.1)
  if (do_r0==1) sum_priors+= log(0.1) - 0.1*r0;
//  if (do_r1==1) sum_priors+= log(0.1) - 0.1*r1;
  if (do_r1==1) sum_priors+= R::dnorm(rho1, 0, 1, true); //N(0,1) prior - log scale
  if (do_r2==1) sum_priors+= log(0.1) - 0.1*r2;
  if (do_k==1) sum_priors+= log(0.001) - 0.001*k;
  // prior is norexponential on mal on log_s
  if (do_s==1) sum_priors+= log(0.01) - 0.01 * log_s; //N(0,3) prior log scale

  return(sum_priors);

}

void initMCMC(int do_r0,int do_r1,int do_r2,int do_T0,int do_T1,int do_T2,int do_k, int do_s,
    double &r0_cur, double &rho1_cur, double &r2_cur, int &T0_cur, int & T1_cur, int &T2_cur, double &k_cur, double & log_s_cur,
            double&logL_cur, double& logLEpid_cur, double & logPrior_cur,
            int type,int dim_r, int lW, int ahead, int incub, int nCountry, int T0_max,
            IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up, IntegerVector delta1,
            NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
            NumericVector delai_sub,
            NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
            int typeEpid, NumericVector epidUK, int t0Epid, int & durEpid, double &lfSumEpid, NumericVector & lfEpid,
            NumericVector init) {
  //if t0Epid is -1, turn off epid computaiton
  r0_cur=init[0];
  T0_cur=init[1];
  // we provide r1 in init, so initialize rho1 from this
  rho1_cur=log(init[2]/init[0]);
  T1_cur=init[3];

  r2_cur=init[4];
  T2_cur=init[5];

  k_cur = init[6];
  log_s_cur = log(init[7]); // on the log scale

  double s_cur=exp(log_s_cur);

    // pointer to function for logL
    double (*compute_logL)(double,double,double, int,int,int, double, double,
            int,int, int, int, int,
            IntegerVector, IntegerVector,IntegerVector,IntegerVector,
            NumericVector, NumericVector, int, int,
            NumericVector,
            NumericVector, NumericVector, double, int);

    double (*compute_logL_epid)(double, double, int, int, double,
            NumericVector, int, int, double, NumericVector);

    compute_logL= NULL;
    compute_logL_epid= NULL;

    int conditional=false;
    switch(type){
    case 1:
      compute_logL = compute_logL_1sub_pois;
      break;
    case 2:
      compute_logL = compute_logL_1sub_nb;
      break;
    case 3:
      conditional=true;
      compute_logL = compute_logL_1sub_pois;
      break;
    case 4:
      conditional = true;
      compute_logL = compute_logL_1sub_nb;
      break;
    case 5:
      compute_logL = compute_logL_1sub_nb2;
      break;
    case 6:
      conditional = true;
      compute_logL = compute_logL_1sub_nb2;
      break;
    case 7:
      compute_logL = compute_logL_1sub_auto_pois;
      break;
    case 8:
      conditional = true;
      compute_logL = compute_logL_1sub_auto_pois;
      break;
    }

    switch(typeEpid){
    case 1:
      compute_logL_epid= compute_logL_epid_pois;
      break;
    case 2:
      compute_logL_epid= compute_logL_epid_nb;
      break;
    }

    //compute r1_cur for likelihood
    double r1_cur = exp(rho1_cur) * r0_cur;
    logL_cur=compute_logL(r0_cur,r1_cur,r2_cur, T0_cur,T1_cur, T2_cur, k_cur, s_cur,
                                 dim_r,
                                 lW,ahead, incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp, s, dt_s_increase, iUK,
                                 delai_sub,
                            p_over_R,cum_growth_rate, f_before_T0,
                            conditional);

    Rcerr << "logL init "<< logL_cur <<"\n";

    durEpid = epidUK.size();
    NumericVector tmp(1);
    tmp[0]=sum(epidUK);
    tmp = lfactorial(tmp);
    lfSumEpid= tmp[0];

    lfEpid = lfactorial(epidUK);

    logLEpid_cur=0;
    if (typeEpid >0){
      // compute logL for England
      logLEpid_cur = compute_logL_epid(r0_cur,r1_cur,T0_cur,T1_cur, k_cur, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
    }
    Rcerr << "logLEpid init "<< logLEpid_cur <<"\n";

    //compute priors
    logPrior_cur = compute_priors(do_r0, do_r1, do_r2, do_k, do_s,  r0_cur, rho1_cur, r2_cur, k_cur, log_s_cur);
    Rcerr << "logPrior init "<< logPrior_cur <<"\n";
}

void stepMCMC(int do_r0,int do_r1,int do_r2,int do_T0,int do_T1,int do_T2,int do_k, int do_s,
          double& r0_cur, double& rho1_cur, double &r2_cur, int & T0_cur, int & T1_cur, int &T2_cur, double &k_cur, double &log_s_cur,
          double&logL_cur, double& logLEpid_cur, double & logPrior_cur,
          int type,int dim_r, int lW, int ahead, int incub, int nCountry, int T0_max,
          IntegerVector Ts, IntegerVector Ti_lo,IntegerVector Ti_up, IntegerVector delta1,
          NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
          NumericVector delai_sub,
          NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
          int typeEpid, NumericVector epidUK, int t0Epid, int durEpid, double  lfSumEpid, NumericVector lfEpid,
          NumericVector sd,NumericVector accept
          ) {
  // return acceptance in accept
  // nothing is written in results -> defer to sampler function

  // pointer to function for logL
  double (*compute_logL)(double,double,double, int,int,int, double, double,
          int,int, int, int, int,
          IntegerVector, IntegerVector,IntegerVector,IntegerVector,
          NumericVector, NumericVector, int, int,
          NumericVector,
          NumericVector, NumericVector, double, int);


  double (*compute_logL_epid)(double, double, int, int, double,
          NumericVector, int, int, double, NumericVector);

  compute_logL= NULL;
  compute_logL_epid= NULL;

  int conditional=false;
  switch(type){
  case 1:
    compute_logL = compute_logL_1sub_pois;
    break;
  case 2:
    compute_logL = compute_logL_1sub_nb;
    break;
  case 3:
    conditional=true;
    compute_logL=compute_logL_1sub_pois;
    break;
  case 4:
    conditional=true;
    compute_logL=compute_logL_1sub_nb;
    break;
  case 5:
    compute_logL=compute_logL_1sub_nb2;
    break;
  case 6:
    conditional=true;
    compute_logL=compute_logL_1sub_nb2;
    break;
  case 7:
    compute_logL=compute_logL_1sub_auto_pois;
    break;
  case 8:
    conditional=true;
    compute_logL=compute_logL_1sub_auto_pois;
    break;
  case 9:
    compute_logL=compute_logL_1sub_auto_nb;
    break;
  }
  switch(typeEpid) {
  case 1:
    compute_logL_epid= compute_logL_epid_pois;
    break;
  case 2:
    compute_logL_epid = compute_logL_epid_nb;
    break;
  }

  double r1_cur = r0_cur*exp(rho1_cur);
  double s_cur = exp(log_s_cur);

  //sampling r0
  if (do_r0==1) {
    double r0_new = rnorm_trunc(r0_cur, sd[0], 0.0,10.0);

    //compute r1_cur
    r1_cur = r0_new * exp(rho1_cur);

    double log_P_old_new = R::dnorm(r0_cur, r0_new, sd[0],true) - R::pnorm(0,r0_new,sd[0],false,true);
    double log_P_new_old = R::dnorm(r0_new, r0_cur, sd[0],true) - R::pnorm(0,r0_cur,sd[0],false,true);
    double logL_new=compute_logL(r0_new,r1_cur,r2_cur,T0_cur,T1_cur,T2_cur,k_cur,s_cur,
                                 dim_r,lW, ahead,incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase, iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);

    double logLEpid_new=0;
    if (typeEpid>0){
      // compute logL for England
      logLEpid_new = compute_logL_epid(r0_new,r1_cur,T0_cur,T1_cur, k_cur, epidUK, t0Epid , durEpid , lfSumEpid, lfEpid);
    }
    //prior are computed with rho1
    double logPrior_new = compute_priors(do_r0, do_r1, do_r2, do_k, do_s,
                                         r0_new, rho1_cur, r2_cur, k_cur, log_s_cur);
    //move priors here not in logL
    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new + logPrior_new - logL_cur - logLEpid_cur - logPrior_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur=logLEpid_new;
      logPrior_cur=logPrior_new;
      r0_cur=r0_new;
      accept[0]+=1.0;
    }
  }
  // T0
  //always recompute r1_cur
  r1_cur = r0_cur * exp(rho1_cur);

  if (do_T0==1) {
    int T0_up = (int) fmin(T0_max,T0_cur+sd[1]);
    int T0_lo = (int) fmax(1,T0_cur-sd[1]);
    IntegerVector pool = seq(T0_lo, T0_up);
    random_shuffle(pool.begin(), pool.end());
    int T0_new = pool[0];
    double log_P_new_old = -log(T0_up+1-T0_lo);

    T0_up = (int) fmin(T0_max,T0_new+sd[1]);
    T0_lo = (int) fmax(1,T0_new-sd[1]);
    double log_P_old_new = -log(T0_up+1-T0_lo);

    double logL_new=compute_logL(r0_cur,r1_cur,r2_cur,T0_new,T1_cur,T2_cur,k_cur,s_cur,
                                 dim_r,
                                 lW, ahead, incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase,iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);
    double logLEpid_new=0;
    if (typeEpid>0){
      // compute logL for England
      logLEpid_new = compute_logL_epid(r0_cur,r1_cur,T0_new,T1_cur, k_cur, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
    }
    // flat prior for T0

    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new - logL_cur - logLEpid_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur=logLEpid_new;
      T0_cur=T0_new;
      accept[1]+=1.0;
    }
  }

  //sampling rho1
  r1_cur = r0_cur * exp(rho1_cur);
  if (do_r1==1) {
//    double log_phi_new = sd[2]*norm_rand() + log(r1_cur/r0_cur);
//    double r1_new = rnorm_trunc(r1_cur, sd[1], 0.0,10.0);
    double rho1_new = rho1_cur+ sd[2] * norm_rand();
//    double r1_new = r1_cur * exp(sd[2]*norm_rand());
// Rcout <<"r1_new "<<r1_new<<"\n";
//    double log_P_old_new = R::dnorm(r1_cur, r1_new, sd[1],true) - R::pnorm(0,r1_new,sd[1],false,true);
    double log_P_old_new =0.0;
//    double log_P_new_old = R::dnorm(r1_new, r1_cur, sd[1],true) - R::pnorm(0,r1_cur,sd[1],false,true);
    double log_P_new_old = 0.0;

    double r1_new = r0_cur * exp(rho1_new);
    double logL_new=compute_logL(r0_cur,r1_new,r2_cur,T0_cur,T1_cur,T2_cur,k_cur,s_cur,
                                 dim_r,
                                 lW,ahead,incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase,iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);

    double logLEpid_new=0;
    if (typeEpid>0){
      // compute logL for England
      logLEpid_new = compute_logL_epid(r0_cur,r1_new, T0_cur,T1_cur, k_cur, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
    }

    double logPrior_new = compute_priors(do_r0, do_r1, do_r2, do_k,do_s,  r0_cur, rho1_new, r2_cur, k_cur, log_s_cur);

    //move priors here not in logL
    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new + logPrior_new - logL_cur - logLEpid_cur - logPrior_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur=logLEpid_new;
      logPrior_cur = logPrior_new;
      rho1_cur=rho1_new;
      accept[2]+=1.0;
    }
  }

  r1_cur = r0_cur * exp(rho1_cur);
  //  sd = as.vector(c(sd$r,sd$T0,sd$r2,sd$Tcp2,sd$r3,sd$Tcp3,sd$k))
  if (do_T1==1) {
      int T1max=(int)fmax(123.0, lW);
      int T1min=62;
      int T1_up = (int) fmin(T1max-1,T1_cur+sd[3]);
      int T1_lo = (int) fmax(T1min,T1_cur-sd[3]);
      IntegerVector pool = seq(T1_lo, T1_up);
      random_shuffle(pool.begin(), pool.end());
      int T1_new = pool[0];
      double log_P_new_old = -log(T1_up+1-T1_lo);

      T1_up = (int) fmin(T1max,T1_new+sd[3]);
      T1_lo = (int) fmax(T1min,T1_new-sd[3]);
      double log_P_old_new = -log(T1_up+1-T1_lo);

      double logL_new=compute_logL(r0_cur,r1_cur,r2_cur,T0_cur,T1_new,T2_cur,k_cur,s_cur,
                                   dim_r,
                                   lW,ahead,incub,nCountry,
                                   Ts, Ti_lo,Ti_up, delta1,
                                   tKp,s,dt_s_increase,iUK,
                                   delai_sub,
                                   p_over_R,cum_growth_rate, f_before_T0,
                                   conditional);

      double logLEpid_new=0;
      if (typeEpid>0){
        // compute logL for England
        logLEpid_new = compute_logL_epid(r0_cur,r1_cur,T0_cur,T1_new, k_cur, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
      }
      // flat prior

      if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new - logL_cur - logLEpid_cur + log_P_old_new - log_P_new_old) {
        logL_cur=logL_new;
        logLEpid_cur = logLEpid_new;
        T1_cur=T1_new;
        accept[3]+=1.0;
      }
  }

  r1_cur = r0_cur * exp(rho1_cur);
  //sampling r2
  if (do_r2==1) {
    double r2_new = rnorm_trunc(r2_cur, sd[4], 0.0,10.0);
    double log_P_old_new = R::dnorm(r2_cur, r2_new, sd[4],true) - R::pnorm(0,r2_new,sd[4],false,true);
    double log_P_new_old = R::dnorm(r2_new, r2_cur, sd[4],true) - R::pnorm(0,r2_cur,sd[4],false,true);
    double logL_new=compute_logL(r0_cur,r1_cur,r2_new,T0_cur,T1_cur,T2_cur,k_cur,s_cur,
                                 dim_r,
                                 lW,ahead,incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase,iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);

    double logLEpid_new=0;
    if (typeEpid>0){
      // compute logL for England
      logLEpid_new = compute_logL_epid(r0_cur,r1_cur,T0_cur,T1_cur, k_cur, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
    }

    double logPrior_new = compute_priors(do_r0, do_r1, do_r2, do_k, do_s, r0_cur, rho1_cur, r2_new, k_cur, log_s_cur);

    //move priors here not in logL
    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new + logPrior_new - logL_cur - logLEpid_cur - logPrior_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur = logLEpid_new;
      logPrior_cur=logPrior_new;
      r2_cur=r2_new;
      accept[4]+=1.0;
    }
  }
  //
  if (do_T2==1) {

  }

  r1_cur = r0_cur * exp(rho1_cur);
  //k
  if (do_k==1) {
    double k_new = rnorm_trunc(k_cur, sd[6], 0.0,10.0);
    double log_P_old_new = R::dnorm(k_cur, k_new, sd[6],true) - R::pnorm(0,k_new,sd[6],false,true);
    double log_P_new_old = R::dnorm(k_new, k_cur, sd[6],true) - R::pnorm(0,k_cur,sd[6],false,true);

    double logL_new=compute_logL(r0_cur,r1_cur,r2_cur,T0_cur,T1_cur,T2_cur,k_new,s_cur,
                                 dim_r,
                                 lW,ahead,incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase,iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);

    double logLEpid_new=0;
    if (typeEpid>0){
      // compute logL for England
      logLEpid_new = compute_logL_epid(r0_cur,r1_cur,T0_cur,T1_cur, k_new, epidUK, t0Epid , durEpid, lfSumEpid, lfEpid);
    }
    //move priors here not in logL
    double logPrior_new = compute_priors(do_r0, do_r1, do_r2, do_k, do_s, r0_cur, rho1_cur, r2_cur, k_new, log_s_cur);

    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new + logPrior_new - logL_cur - logLEpid_cur -logPrior_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur=logLEpid_new;
      logPrior_cur = logPrior_new;
      k_cur=k_new;
      accept[6]+=1.0;
    }
  }

  //s

  if (do_s==1) {
    // new log_s value truncated to 0/10 
    double log_s_new = rnorm_trunc(log_s_cur, sd[7], 0.0,10.0);
    double log_P_old_new = R::dnorm(log_s_cur, log_s_new, sd[7],true) - log(R::pnorm(10.0,log_s_new,sd[7],true,false)-R::pnorm(0.0,log_s_new,sd[7],true,false));
    double log_P_new_old = R::dnorm(log_s_new, log_s_cur, sd[7],true) - log(R::pnorm(10.0,log_s_cur,sd[7],true,false)-R::pnorm(0.0,log_s_cur,sd[7],true,false));
    
    double s_new=exp(log_s_new);

    double logL_new=compute_logL(r0_cur,r1_cur,r2_cur,T0_cur,T1_cur,T2_cur,k_cur,s_new,
                                 dim_r, lW,ahead,incub,nCountry,
                                 Ts, Ti_lo,Ti_up, delta1,
                                 tKp,s,dt_s_increase,iUK,
                                 delai_sub,
                                 p_over_R,cum_growth_rate, f_before_T0,
                                 conditional);

    double logLEpid_new=logLEpid_cur;

    //move priors here not in logL
    double logPrior_new = compute_priors(do_r0, do_r1, do_r2, do_k, do_s, r0_cur, rho1_cur, r2_cur, k_cur, log_s_new);

    if (log(R::runif(0.0,1.0)) < logL_new + logLEpid_new + logPrior_new - logL_cur - logLEpid_cur -logPrior_cur + log_P_old_new - log_P_new_old) {
      logL_cur=logL_new;
      logLEpid_cur=logLEpid_new;
      logPrior_cur = logPrior_new;
      log_s_cur=log_s_new;
      accept[7]+=1.0;
    }
  }
}



// [[Rcpp::export]]
List sampler(int type, int R, int thin, int warmup, IntegerVector doPar,
             NumericVector init, int dim_r,
             int lW, int ahead, int incub, int nCountry,
             IntegerVector Ts,
             IntegerVector Ti_lo, IntegerVector Ti_up,
             IntegerVector delta1,
             NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
             NumericVector delai_sub,
             NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0,
             int typeEpid, NumericVector epidUK, int t0Epid,
             NumericVector sd, int T0_max, 
             int nchain)
{
  // PYB change :2022-03-17: add ahead -> data are lW+ahead long. logL must be computed up to lW;
  // but preparatory computations may be done up to ahead
  // PYB change 2022-05-06 : add likelihood for cases in the UK,
  // based on Poisson distribution for epidUK from t0Epid
  // typeEpid = 0 to turn off the feature, 1/pois; 2/nb
  // t0Epid is measure from date start
  // change 2023 04 18
  // add f_before_T0 : 1 if count before, 0 otherwise
  //v3 : add s, dt_s_increase, iUK as parameters
  Rcerr<<"v3.2\n";
  Rcerr<<"LL : ";
  switch(type) {
  case 1:
    Rcerr << "poisson";
    break;
  case 2:
    Rcerr << "negative binomial";
    break;
  case 3:
    Rcerr << "cond poisson";
    break;
  case 4:
    Rcerr << "cond negative binomial";
    break;
  case 5:
    Rcerr << "negative binomial type 2";
    break;
  case 6:
    Rcerr << "cond negative binomial type 2";
    break;
  case 7:
    Rcerr << "poisson with autochtonous transmission";
    break;
  case 8:
    Rcerr << "cond poisson with autochtonous transmission";
    break;
  case 9:
    Rcerr << "NB with autochtonous transmission";
    break;
  }

  Rcerr<<"\nLLEpid : ";
  switch(typeEpid) {
    case 0:
    Rcerr << "no epid";
      break;
  case 1:
    Rcerr<<"pois";
    break;
  case 2:
    Rcerr<<"nb";
    break;
  }

  //make a big table for return
  //3*r + k + 3* T + k + s.increase + logL + logLEpid + logP +  lp__ : 11*R
  NumericMatrix res(R,12);

  int do_r0=0;
  int do_r1=0;
  int do_r2=0;

  int do_T0=0;
  int do_T1=0;
  int do_T2=0;

  int do_k=0;

  int do_s=0;

  // choose parameter to update
  if (doPar[0]==1) do_r0=1;
  if (doPar[1]==1) do_T0=1;

  if (doPar[2]==1) do_r1=1;
  if (doPar[3]==1) do_T1=1;

  if (doPar[4]==1) do_r2=1;
  if (doPar[5]==1) do_T2=1;

  if (doPar[6]==1) do_k=1;

  if (doPar[7]==1) do_s=1;

  Rcerr << "param: " << doPar<< " "<<do_r0<<" "<<do_T0<<" "<<do_r1<<" "<<do_T1<<" "<<do_r2<<" "<<do_T2<<" "<<do_k<<" "<<do_s<<"""\n";

  NumericVector accept(8);
  for (int i=0; i<8; i++) accept[i]=0.0;
  Rcerr << "accept "<< accept<<"\n";

  double r0_cur;
  double r1_cur;
  //reparametrisation avec rho1; where rho1 = log(r1/r0) ~ N()
  double rho1_cur;

  double r2_cur;
  int T0_cur;
  int T1_cur;
  int T2_cur;
  double k_cur;
  double log_s_cur;
  double s_cur;
  double logL_cur;
  double logLEpid_cur;
  double logPrior_cur;

  Rcerr << "chain "<< nchain << " proposal init "<< sd <<"\n";
  double lfSumEpid; //o stor log factorial of sumX
  NumericVector lfEpid; //to store log factorial of epid
  int durEpid;
    //init logL
  initMCMC(do_r0,do_r1,do_r2,do_T0,do_T1,do_T2,do_k,do_s,
           r0_cur, rho1_cur, r2_cur, T0_cur, T1_cur, T2_cur, k_cur, log_s_cur,
           logL_cur, logLEpid_cur, logPrior_cur,
           type, dim_r, lW, ahead, incub, nCountry, T0_max,
           Ts, Ti_lo,Ti_up, delta1,
           tKp, s, dt_s_increase, iUK,
           delai_sub,
           p_over_R,cum_growth_rate,f_before_T0,
           typeEpid, epidUK, t0Epid, durEpid, lfSumEpid, lfEpid,
           init);

  r1_cur=r0_cur*exp(rho1_cur);
  Rcerr << "chain " <<nchain <<  " param init "<< r0_cur<<" "<< T0_cur<<" "<< r1_cur<<" "<< T1_cur<<" "<< r2_cur<<" "<< T2_cur<<" "<< k_cur<<" " <<"\n";
  Rcerr << "chain " <<nchain << " target init "<<logL_cur<<" " <<logLEpid_cur<< " "<<logPrior_cur<<" "<<logL_cur + logPrior_cur<<"\n";
  int pctWarmup=warmup/10;
  int pctSampling=R/10;
  Rcerr<<"chain " <<nchain <<" warmup "<<warmup<<" then sample "<<R<<" (thinning "<<thin<<") built in\n";
  //warmup

  //sd = c(sd$r,sd$T0,sd$r2,sd$Tcp2,sd$r3,sd$Tcp3,sd$k, sd$s)
    
  for (int iter=0; iter <warmup; iter++) {
    NumericVector accept_no(8);
    if (!(iter%pctWarmup)) Rcerr << "chain " <<nchain << " Warmup " << (100*iter)/warmup << "%\n";


    stepMCMC(do_r0,do_r1,do_r2,do_T0,do_T1,do_T2,do_k,do_s,
             r0_cur, rho1_cur,r2_cur,T0_cur,T1_cur,T2_cur, k_cur, log_s_cur,
             logL_cur, logLEpid_cur, logPrior_cur,
             type, dim_r, lW, ahead, incub, nCountry, T0_max,
             Ts, Ti_lo,Ti_up, delta1,
             tKp, s, dt_s_increase,  iUK,
             delai_sub,
             p_over_R, cum_growth_rate, f_before_T0,
             typeEpid,epidUK, t0Epid, durEpid, lfSumEpid, lfEpid,
             sd, accept_no);
  }
  //sampling
  for (int iter=0; iter <R; iter++) {
    if (!(iter%pctSampling)) Rcerr << "chain " <<nchain <<" Sampling " << (100*iter)/R << "%\n";
    for (int inner=0; inner<thin; inner++ ) {
      stepMCMC(do_r0,do_r1,do_r2,do_T0,do_T1,do_T2,do_k,do_s,
               r0_cur, rho1_cur,r2_cur,T0_cur,T1_cur,T2_cur, k_cur, log_s_cur,
               logL_cur, logLEpid_cur, logPrior_cur,
               type, dim_r, lW, ahead, incub, nCountry, T0_max,
               Ts, Ti_lo,Ti_up, delta1,
               tKp, s, dt_s_increase,  iUK,
               delai_sub,
               p_over_R,cum_growth_rate, f_before_T0,
               typeEpid,epidUK, t0Epid, durEpid, lfSumEpid,lfEpid,
               sd, accept);
    }

    res(iter,0)=r0_cur;
    res(iter,1)=T0_cur;
    res(iter,2)=r0_cur*exp(rho1_cur);
    res(iter,3)=T1_cur;
    res(iter,4)=r2_cur;
    res(iter,5)=T2_cur;
    res(iter,6)=k_cur;
    res(iter,7)=exp(log_s_cur);

    res(iter,8)=logL_cur;
    res(iter,9)=logLEpid_cur;
    res(iter,10)=logPrior_cur;
    res(iter,11)=logL_cur+logLEpid_cur+logPrior_cur;
  }

  accept = accept/(R*thin);
  List L=List::create(Named("res")=res, _["accept"]=accept);

  return(L);
}

void compQuantiles(int lW, int R, NumericMatrix source, int start, NumericVector lo,  NumericVector med, NumericVector up, NumericVector moy)
{
  for (int t=0; t < lW; t++) {
    NumericVector y=source(_,t);
    y.sort();
    lo[start+t] = y[(int) (0.025*R)];
    med[start+t] = y[(int) (0.5*R)];
    up[start+t] = y[(int) (0.975*R)];
    moy[start+t]=mean(y);
  }
}

// [[Rcpp::export]]
List calc_F_country(NumericVector res, int R,
                    int lW, int ahead, int nCountry, int dim_r,
                    int incub,  IntegerVector Ts, IntegerVector delta1,
                    NumericVector p,
                    NumericVector tKp, NumericVector s, int dt_s_increase, int iUK,
                    NumericVector delai_sub,
                    NumericVector p_over_R, NumericVector cum_growth_rate,
                    int computeAutoEpid,double f_before_T0) {

  //all generated quantities are lW+ahead
  // res holds s
  
  // computeAutoEpid is TRUE if we want to compute number of cases arising from local transmission
  //this requires that p_over_R and cum_growth_rate are not NULL - this must be tested before the call

  //parametre ahead is time computation in the future
  int lW_ahead = lW+ ahead;

  // nWeeks=data$nWeeks
  NumericVector inc_lo(lW_ahead);
  NumericVector inc_med(lW_ahead);
  NumericVector inc_up(lW_ahead);
  NumericVector inc_mean(lW_ahead);

  NumericVector inc_lo_norm(lW_ahead);
  NumericVector inc_med_norm(lW_ahead);
  NumericVector inc_up_norm(lW_ahead);
  NumericVector inc_mean_norm(lW_ahead);

  NumericMatrix FSeq_lo(lW_ahead,nCountry);
  NumericMatrix FSeq_med(lW_ahead,nCountry);
  NumericMatrix FSeq_up(lW_ahead,nCountry);
  NumericMatrix FSeq_mean(lW_ahead,nCountry);

  NumericMatrix FSub_lo(lW_ahead,nCountry);
  NumericMatrix FSub_med(lW_ahead,nCountry);
  NumericMatrix FSub_up(lW_ahead,nCountry);
  NumericMatrix FSub_mean(lW_ahead,nCountry);

  NumericMatrix Ffirst_lo(lW_ahead,nCountry);
  NumericMatrix Ffirst_med(lW_ahead,nCountry);
  NumericMatrix Ffirst_up(lW_ahead,nCountry);
  NumericMatrix Ffirst_mean(lW_ahead,nCountry);

  NumericMatrix Lfirst_lo(lW_ahead,nCountry);
  NumericMatrix Lfirst_med(lW_ahead,nCountry);
  NumericMatrix Lfirst_up(lW_ahead,nCountry);
  NumericMatrix Lfirst_mean(lW_ahead,nCountry);

  NumericMatrix Lalpha_lo(lW_ahead,nCountry);
  NumericMatrix Lalpha_med(lW_ahead,nCountry);
  NumericMatrix Lalpha_up(lW_ahead,nCountry);
  NumericMatrix Lalpha_mean(lW_ahead,nCountry);

  NumericMatrix Pcol_lo(lW_ahead,nCountry);
  NumericMatrix Pcol_med(lW_ahead,nCountry);
  NumericMatrix Pcol_up(lW_ahead,nCountry);
  NumericMatrix Pcol_mean(lW_ahead,nCountry);

  NumericVector FSub_all_lo(lW_ahead);
  NumericVector FSub_all_med(lW_ahead);
  NumericVector FSub_all_up(lW_ahead);
  NumericVector FSub_all_mean(lW_ahead);

  NumericVector FSeq_all_lo(lW_ahead);
  NumericVector FSeq_all_med(lW_ahead);
  NumericVector FSeq_all_up(lW_ahead);
  NumericVector FSeq_all_mean(lW_ahead);

  NumericVector FSeq_Sub_lo(lW_ahead);
  NumericVector FSeq_Sub_med(lW_ahead);
  NumericVector FSeq_Sub_up(lW_ahead);
  NumericVector FSeq_Sub_mean(lW_ahead);

  NumericVector Ffirst_all_lo(lW_ahead);
  NumericVector Ffirst_all_med(lW_ahead);
  NumericVector Ffirst_all_up(lW_ahead);
  NumericVector Ffirst_all_mean(lW_ahead);

  NumericMatrix exp_r_t(R,lW_ahead);
  NumericMatrix exp_r_t_norm(R,lW_ahead);
  NumericMatrix exp_r_t_travel(R,lW_ahead);

  double TemergMax = *min_element(Ts.begin(),Ts.end());

  NumericVector Temerg(TemergMax);
  
  for (int iter=0; iter < R; iter ++) {
    double r0=res(iter,0);
    double T0=res(iter,1);
    double r1=res(iter,2);
    double T1=res(iter,3);
    double r2=res(iter,4);
    double T2=res(iter,5);
    double k=res(iter,6);

    //to prevent unused
    k=k;
    //incidence
    double tmp_sum=0.0;
    
    for (int t=0; t < T0; t++) {
      double tmp=f_before_T0 * exp(r0 * (t-T0));
      exp_r_t(iter,t)=tmp;
      tmp_sum+=tmp;
      Temerg(t) = (-1.0 + exp(exp(r0*(t-T0))))*exp(-((exp(-r0*T0)*(-1.0+exp(r0+r0*t)))/(-1.0+exp(r0))))/R;
    }
    for (int t=T0; t < T1; t++) {
      double tmp = exp(r0 * (t-T0));
      exp_r_t(iter,t)=tmp;
      tmp_sum+=tmp;
    }
    for (int t=T1; t < T2; t++) {
      double tmp = exp(r0 * (T1-T0) +  r1*(t-T1));
      exp_r_t(iter,t)=tmp;
      tmp_sum+=tmp;
    }
    for (int t=T2; t < lW_ahead; t++) {
      double tmp = exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
      exp_r_t(iter,t)=tmp;
      tmp_sum+=tmp;
    }

    for (int t=0; t<lW_ahead;t++)
      exp_r_t_norm(iter,t) = exp_r_t(iter,t)/tmp_sum;

    for(int u=0; u<incub; u++){
      for (int t=0; t+u <lW_ahead; t++){
        exp_r_t_travel(iter,t+u) += exp_r_t(iter,t);
      }
    }
  }
  //quantiles each col
  compQuantiles(lW_ahead,R,exp_r_t,0,inc_lo,inc_med,inc_up,inc_mean);
  compQuantiles(lW_ahead,R,exp_r_t_norm,0,inc_lo_norm,inc_med_norm,inc_up_norm,inc_mean_norm);

  NumericMatrix lambda_seq(R,lW_ahead);
  NumericMatrix lambda_first(R,lW_ahead);
  NumericMatrix lambda_sub(R,lW_ahead);
  NumericMatrix lambda_auto(R,lW_ahead);
  NumericMatrix alpha(R,lW_ahead);

  int lWSquared=lW_ahead*lW_ahead;

  NumericMatrix FSub_all(R,lW_ahead);
  NumericMatrix FSeq_all(R,lW_ahead);
  NumericMatrix Ffirst_all(R,lW_ahead);
  NumericMatrix FSeq_Sub(R,lW_ahead);

  for (int i=0; i<nCountry; i++) { // loop on countries
    //Rcout << "start " << i << std::endl ;
    for(int t=0; t<lW_ahead; t++) {
      for (int iter=0; iter <R; iter++) {
        double s_increase=res(iter,7);
        // t goes up to lW_ahead, but should be <t for data
//        lambda_seq[iter+t*R] = exp_r_t_travel[iter+t*R]*tKps[t+i*lW_ahead];
        if ((t >= dt_s_increase) && (i!=iUK)) {
          lambda_seq[iter+t*R] = exp_r_t_travel[iter+t*R]*tKp[t+i*lW_ahead]*min(s[i+t*nCountry]*s_increase,1.0);
        } else {
          lambda_seq[iter+t*R] = exp_r_t_travel[iter+t*R]*tKp[t+i*lW_ahead]*min(s[i+t*nCountry],1.0);
        }
        lambda_first[iter+t*R] = exp_r_t_travel[iter+t*R]*p[i+t*nCountry];
        lambda_sub[iter+t*R] = 0.0;
        if (computeAutoEpid == 1) {
          lambda_auto[iter+t*R] = exp_r_t_travel[iter+t*R]*p_over_R[t+i*lW_ahead];
        } else {
          lambda_auto[iter+t*R]=0.0;
        }
        alpha[iter+t*R]=0.0;
      }
    }
    //Rcout << "lambda done" << std::flush;
    
    
    if (computeAutoEpid==1) {
      for(int t=0; t<lW_ahead; t++) {
        for(int u=0; u<t; u++) {
          for (int iter=0; iter<R; iter++) {
            //alpha is the cumulated number born from cases introduced
            alpha[iter+t*R] += lambda_auto[iter+ u*R] * cum_growth_rate[u + t * lW_ahead + i *lWSquared];
          }
        }
      }
    }
    //Rcout << "alpha done" << std::flush;
    
    for(int u=0; u<lW_ahead; u++) {// date sub
      for(int t=0; t<=u; t++) { //date col... must be before u
        for (int iter=0; iter<R; iter++) {
          lambda_sub[iter+u*R] += delai_sub[t + u*lW_ahead + i*lWSquared] * lambda_seq[iter+ t*R];
        }
      }
      
    }

    //Rcout << "lambda_sub done" << std::flush;
    
    NumericMatrix Flambda_sub(R,lW_ahead);
    NumericMatrix Flambda_seq(R,lW_ahead);
    NumericMatrix Flambda_first(R,lW_ahead);
    NumericMatrix Pcol(R,lW_ahead); // Prob of having collected at time t - conditional on submission date

    
    for (int iter=0; iter <R; iter++) {
      Flambda_sub[iter] = lambda_sub[iter];
      Flambda_seq[iter] = lambda_seq[iter];
      Flambda_first[iter] = lambda_first[iter];
    }

    for(int t=1; t<lW_ahead; t++) {
      for (int iter=0; iter <R; iter++) {
        Flambda_sub[iter+t*R] += Flambda_sub[iter+(t-1)*R] + lambda_sub[iter+t*R];
        Flambda_seq[iter+t*R] += Flambda_seq[iter+(t-1)*R] + lambda_seq[iter+t*R] ;
        Flambda_first[iter+t*R] += Flambda_first[iter+(t-1)*R] + lambda_first[iter+t*R];
      }
    }


    for(int t=0; t<lW_ahead; t++) { // these are probabilities in the Poisson model
      for (int iter=0; iter <R; iter++) {
        Flambda_sub[iter+t*R] = -expm1(-Flambda_sub[iter+(t)*R]);
        Flambda_seq[iter+t*R] = -expm1(-Flambda_seq[iter+(t)*R]);
        Flambda_first[iter+t*R] = -expm1(-Flambda_first[iter+(t)*R]);
      }
    }
    //Rcout << "Flambda done" << std::flush;
    
  // f there was a submission, compute conditional distribution
    if (delta1[i]==1) {
      for (int iter=0; iter <R; iter++) {
        double PTs= (lambda_sub[iter+(Ts[i]-1)*R]);
        Pcol[iter+0*R] = lambda_sub[iter+ 0*R]/PTs;
        for(int t=1; t<Ts[i]; t++) { // these are probabilities in the Poisson model
          Pcol[iter+t*R] = Pcol[iter+(t-1)*R] + lambda_seq[iter + t*R] * delai_sub[t + (Ts[i]-1)*lW_ahead + i*lWSquared] / PTs;
        }
        for(int t=Ts[i]; t<lW_ahead; t++) {Pcol[iter+t*R] = 1.0;}
      }
    }
   
//    if (i==1) {
//      Rcerr << "Flambda_sub(1_):\n";
//      for (int t=0; t<lW; t++) {Rcerr << Flambda_sub[0+t*R] << " ";}
//      Rcerr<<"\n";
//    }
      
    compQuantiles(lW_ahead,R,Flambda_sub,i*lW_ahead,FSub_lo,FSub_med,FSub_up,FSub_mean);
    compQuantiles(lW_ahead,R,Flambda_seq,i*lW_ahead,FSeq_lo,FSeq_med,FSeq_up,FSeq_mean);
    compQuantiles(lW_ahead,R,Flambda_first,i*lW_ahead,Ffirst_lo,Ffirst_med,Ffirst_up,Ffirst_mean);
    compQuantiles(lW_ahead,R,lambda_first,i*lW_ahead,Lfirst_lo,Lfirst_med,Lfirst_up,Lfirst_mean);
    compQuantiles(lW_ahead,R,alpha,i*lW_ahead,Lalpha_lo,Lalpha_med,Lalpha_up,Lalpha_mean);
    compQuantiles(lW_ahead,R,Pcol,i*lW_ahead,Pcol_lo,Pcol_med,Pcol_up,Pcol_mean);
    
    FSub_all += Flambda_sub;
    FSeq_all += Flambda_seq;
    Ffirst_all += Flambda_first;

    if (delta1[i]==1) {
      FSeq_Sub += Flambda_seq;
    }
   //Rcout << i << " done" << std::endl;
  }
  compQuantiles(lW_ahead,R,FSub_all,0,FSub_all_lo,FSub_all_med,FSub_all_up,FSub_all_mean);
  compQuantiles(lW_ahead,R,FSeq_all,0,FSeq_all_lo,FSeq_all_med,FSeq_all_up,FSeq_all_mean);
  compQuantiles(lW_ahead,R,Ffirst_all,0,Ffirst_all_lo,Ffirst_all_med,Ffirst_all_up,Ffirst_all_mean);
  compQuantiles(lW_ahead,R,FSeq_Sub,0,FSeq_Sub_lo,FSeq_Sub_med,FSeq_Sub_up,FSeq_Sub_mean);

  List L=List::create(
    Named("incUK")=List::create(Named("lo")=inc_lo,_["med"]=inc_med,_["up"]=inc_up,_["mean"]=inc_mean),
    Named("incUK.norm")=List::create(Named("lo")=inc_lo_norm,_["med"]=inc_med_norm,_["up"]=inc_up_norm,_["mean"]=inc_mean_norm),
    Named("submitted")=List::create(Named("lo")=FSub_lo,_["med"]=FSub_med,_["up"]=FSub_up,_["mean"]=FSub_mean),
    Named("collected")=List::create(Named("lo")=FSeq_lo,_["med"]=FSeq_med,_["up"]=FSeq_up,_["mean"]=FSeq_mean),
    Named("first")=List::create(Named("lo")=Ffirst_lo,_["med"]=Ffirst_med,_["up"]=Ffirst_up,_["mean"]=Ffirst_mean),
    Named("all.sub")=List::create(Named("lo")=FSub_all_lo,_["med"]=FSub_all_med,_["up"]=FSub_all_up,_["mean"]=FSub_all_mean),
    Named("col.sub")=List::create(Named("lo")=FSeq_Sub_lo,_["med"]=FSeq_Sub_med,_["up"]=FSeq_Sub_up,_["mean"]=FSeq_Sub_mean),
    Named("all.col")=List::create(Named("lo")=FSeq_all_lo,_["med"]=FSeq_all_med,_["up"]=FSeq_all_up,_["mean"]=FSeq_all_mean),
    Named("all.first")=List::create(Named("lo")=Ffirst_all_lo,_["med"]=Ffirst_all_med,_["up"]=Ffirst_all_up,_["mean"]=Ffirst_all_mean),
    Named("lambda.first")=List::create(Named("lo")=Lfirst_lo,_["med"]=Lfirst_med,_["up"]=Lfirst_up,_["mean"]=Lfirst_mean),
    Named("alpha")=List::create(Named("lo")=Lalpha_lo,_["med"]=Lalpha_med,_["up"]=Lalpha_up,_["mean"]=Lalpha_mean),
    Named("Pcol")=List::create(Named("lo")=Pcol_lo,_["med"]=Pcol_med,_["up"]=Pcol_up,_["mean"]=Pcol_mean),
    Named("t.emerg")=Temerg
  );

  return(L);
}



  // [[Rcpp::export]]
List calc_F_country_auto(NumericVector res, int R,
                      int lW, int ahead, int nCountry, int dim_r,
                      int incub, IntegerVector delta1,
                      NumericVector p, NumericVector tKps, NumericVector delai_sub,
                      NumericVector p_over_R, NumericVector cum_growth_rate, double f_before_T0) {
  // this compute Fit for each country,
  // including autochtonous transmission using r

    int lW_ahead = lW + ahead;

    // nWeeks=data$nWeeks
    NumericVector inc_lo(lW_ahead);
    NumericVector inc_med(lW_ahead);
    NumericVector inc_up(lW_ahead);
    NumericVector inc_mean(lW_ahead);

    NumericVector inc_lo_norm(lW_ahead);
    NumericVector inc_med_norm(lW_ahead);
    NumericVector inc_up_norm(lW_ahead);
    NumericVector inc_mean_norm(lW_ahead);

    NumericMatrix FSeq_lo(lW_ahead,nCountry);
    NumericMatrix FSeq_med(lW_ahead,nCountry);
    NumericMatrix FSeq_up(lW_ahead,nCountry);
    NumericMatrix FSeq_mean(lW_ahead,nCountry);

    NumericMatrix FSub_lo(lW_ahead,nCountry);
    NumericMatrix FSub_med(lW_ahead,nCountry);
    NumericMatrix FSub_up(lW_ahead,nCountry);
    NumericMatrix FSub_mean(lW_ahead,nCountry);

    NumericMatrix Ffirst_lo(lW_ahead,nCountry);
    NumericMatrix Ffirst_med(lW_ahead,nCountry);
    NumericMatrix Ffirst_up(lW_ahead,nCountry);
    NumericMatrix Ffirst_mean(lW_ahead,nCountry);

    NumericMatrix Lfirst_lo(lW_ahead,nCountry);
    NumericMatrix Lfirst_med(lW_ahead,nCountry);
    NumericMatrix Lfirst_up(lW_ahead,nCountry);
    NumericMatrix Lfirst_mean(lW_ahead,nCountry);

    NumericMatrix Lalpha_lo(lW_ahead,nCountry);
    NumericMatrix Lalpha_med(lW_ahead,nCountry);
    NumericMatrix Lalpha_up(lW_ahead,nCountry);
    NumericMatrix Lalpha_mean(lW_ahead,nCountry);

    NumericVector FSub_all_lo(lW_ahead);
    NumericVector FSub_all_med(lW_ahead);
    NumericVector FSub_all_up(lW_ahead);
    NumericVector FSub_all_mean(lW_ahead);

    NumericVector FSeq_all_lo(lW_ahead);
    NumericVector FSeq_all_med(lW_ahead);
    NumericVector FSeq_all_up(lW_ahead);
    NumericVector FSeq_all_mean(lW_ahead);

    NumericVector FSeq_Sub_lo(lW_ahead);
    NumericVector FSeq_Sub_med(lW_ahead);
    NumericVector FSeq_Sub_up(lW_ahead);
    NumericVector FSeq_Sub_mean(lW_ahead);

    NumericVector Ffirst_all_lo(lW_ahead);
    NumericVector Ffirst_all_med(lW_ahead);
    NumericVector Ffirst_all_up(lW_ahead);
    NumericVector Ffirst_all_mean(lW_ahead);


    NumericMatrix exp_r_t(R,lW_ahead);
    NumericMatrix exp_r_t_norm(R,lW_ahead);
    NumericMatrix exp_r_t_travel(R,lW_ahead);

    for (int iter=0; iter < R; iter ++) {
      double r0=res(iter,0);
      double T0=res(iter,1);
      double r1=res(iter,2);
      double T1=res(iter,3);
      double r2=res(iter,4);
      double T2=res(iter,5);
      double k=res(iter,6);

  //to prevent unused
   k=k;

 // compute exponential growth in the UK
 // in different segments and up to ahead time after lW
      double tmp_sum=0.0;
      for (int t=0; t < T0; t++) {
        double tmp = f_before_T0 * exp(r0 * (t-T0));
        exp_r_t(iter,t)=tmp;
        tmp_sum+=tmp;
      }
      for (int t=T0; t < T1; t++) {
        double tmp = exp(r0 * (t-T0));
        exp_r_t(iter,t)=tmp;
        tmp_sum+=tmp;
      }
      for (int t=T1; t < T2; t++) {
        double tmp = exp(r0 * (T1-T0) +  r1*(t-T1));
        exp_r_t(iter,t)=tmp;
        tmp_sum+=tmp;
      }
      for (int t=T2; t < lW_ahead; t++) {
        double tmp = exp(r0 * (T1-T0) + r1 * (T2-T1)  + r2 * (t-T2));
        exp_r_t(iter,t)=tmp;
        tmp_sum+=tmp;
      }

      for (int t=0; t<lW_ahead;t++)
        exp_r_t_norm(iter,t) = exp_r_t(iter,t)/tmp_sum;

      for(int u=0; u<incub; u++){
        for (int t=0; t+u <lW_ahead; t++){
          exp_r_t_travel(iter,t+u) += exp_r_t(iter,t);
        }
      }
    }
    //quantiles each col
    // exp_r_t
    compQuantiles(lW_ahead,R,exp_r_t,0,inc_lo,inc_med,inc_up,inc_mean);
    //exp_r_t_norm
    compQuantiles(lW_ahead,R,exp_r_t_norm,0,inc_lo_norm,inc_med_norm,inc_up_norm,inc_mean_norm);

    NumericMatrix lambda_seq(R,lW_ahead);
    NumericMatrix lambda_first(R,lW_ahead);
    NumericMatrix lambda_sub(R,lW_ahead);
    NumericMatrix lambda_auto(R,lW_ahead);
    NumericMatrix alpha(R,lW_ahead);

    int lWSquared=lW_ahead*lW_ahead;

    NumericMatrix FSub_all(R,lW_ahead);
    NumericMatrix FSeq_all(R,lW_ahead);
    NumericMatrix Ffirst_all(R,lW_ahead);
    NumericMatrix FSeq_Sub(R,lW_ahead);

    // we have a table with parameters over iterations
    // for each country
    for (int i=0; i<nCountry; i++) {
      // for each time
      for(int t=0; t<lW_ahead; t++) {
        //for each iteration
        for (int iter=0; iter <R; iter++) {
          // these are intensitites
          lambda_seq[iter+t*R] = exp_r_t_travel[iter+t*R]*tKps[t+i*lW_ahead];
          lambda_first[iter+t*R] = exp_r_t_travel[iter+t*R]*p[i+t*nCountry];
          lambda_sub[iter+t*R] = 0.0;
          // lambda_auto is the number introduced having offspring
          lambda_auto[iter+t*R] = exp_r_t_travel[iter+t*R]*p_over_R[t+i*lW_ahead];
          alpha[iter+t*R]=0.0;
        }
      }
      for(int t=0; t<lW_ahead; t++) {
        for(int u=0; u<t; u++) {
          for (int iter=0; iter<R; iter++) {
            //alpha is the cumulated number born from cases introduced
            alpha[iter+t*R] += lambda_auto[iter+ u*R] * cum_growth_rate[u + t * lW_ahead + i *lWSquared];
          }
        }
      }
      for(int u=0; u<lW_ahead; u++) {
        for(int t=0; t<=u; t++) {
          for (int iter=0; iter<R; iter++) {
            lambda_sub[iter+u*R] += delai_sub[t + u*lW_ahead + i*lWSquared] * lambda_seq[iter+ t*R];
          }
        }
      }

      //    if (i==1) {
      //      Rcerr << "lambda_sub(1_):\n";
      //      for (int t=0; t<lW; t++) {Rcerr << lambda_sub[0+t*R] << " ";}
      //      Rcerr<<"\n";
      //    }

      NumericMatrix Flambda_sub(R,lW_ahead);
      NumericMatrix Flambda_seq(R,lW_ahead);
      NumericMatrix Flambda_first(R,lW_ahead);

      for (int iter=0; iter <R; iter++) {
        Flambda_sub[iter] = lambda_sub[iter];
        Flambda_seq[iter] = lambda_seq[iter];
        Flambda_first[iter] = lambda_first[iter];
      }

      for(int t=1; t<lW_ahead; t++) {
        for (int iter=0; iter <R; iter++) {
          Flambda_sub[iter+t*R] += Flambda_sub[iter+(t-1)*R] + lambda_sub[iter+t*R];
          Flambda_seq[iter+t*R] += Flambda_seq[iter+(t-1)*R] + lambda_seq[iter+t*R] ;
          Flambda_first[iter+t*R] += Flambda_first[iter+(t-1)*R] + lambda_first[iter+t*R];
        }
      }


      for(int t=0; t<lW_ahead; t++) {
        for (int iter=0; iter <R; iter++) {
          Flambda_sub[iter+t*R] = 1.0 -exp(-Flambda_sub[iter+(t)*R]);
          Flambda_seq[iter+t*R] = 1.0 - exp(-Flambda_seq[iter+(t)*R]);
          Flambda_first[iter+t*R] = 1.0 - exp(-Flambda_first[iter+(t)*R]);
        }
      }

      //    if (i==1) {
      //      Rcerr << "Flambda_sub(1_):\n";
      //      for (int t=0; t<lW; t++) {Rcerr << Flambda_sub[0+t*R] << " ";}
      //      Rcerr<<"\n";
      //    }

      compQuantiles(lW_ahead,R,Flambda_sub,i*lW_ahead,FSub_lo,FSub_med,FSub_up,FSub_mean);
      compQuantiles(lW_ahead,R,Flambda_seq,i*lW_ahead,FSeq_lo,FSeq_med,FSeq_up,FSeq_mean);
      compQuantiles(lW_ahead,R,Flambda_first,i*lW_ahead,Ffirst_lo,Ffirst_med,Ffirst_up,Ffirst_mean);
      compQuantiles(lW_ahead,R,lambda_first,i*lW_ahead,Lfirst_lo,Lfirst_med,Lfirst_up,Lfirst_mean);
      compQuantiles(lW_ahead,R,alpha,i*lW_ahead,Lalpha_lo,Lalpha_med,Lalpha_up,Lalpha_mean);

      FSub_all += Flambda_sub;
      FSeq_all += Flambda_seq;
      Ffirst_all += Flambda_first;

      if (delta1[i]==1) {
        FSeq_Sub += Flambda_seq;
      }
    }
    compQuantiles(lW_ahead,R,FSub_all,0,FSub_all_lo,FSub_all_med,FSub_all_up,FSub_all_mean);
    compQuantiles(lW_ahead,R,FSeq_all,0,FSeq_all_lo,FSeq_all_med,FSeq_all_up,FSeq_all_mean);
    compQuantiles(lW_ahead,R,Ffirst_all,0,Ffirst_all_lo,Ffirst_all_med,Ffirst_all_up,Ffirst_all_mean);
    compQuantiles(lW_ahead,R,FSeq_Sub,0,FSeq_Sub_lo,FSeq_Sub_med,FSeq_Sub_up,FSeq_Sub_mean);

    
    
    List L=List::create(
      Named("incUK")=List::create(Named("lo")=inc_lo,_["med"]=inc_med,_["up"]=inc_up,_["mean"]=inc_mean),
      Named("incUK.norm")=List::create(Named("lo")=inc_lo_norm,_["med"]=inc_med_norm,_["up"]=inc_up_norm,_["mean"]=inc_mean_norm),
      Named("submitted")=List::create(Named("lo")=FSub_lo,_["med"]=FSub_med,_["up"]=FSub_up,_["mean"]=FSub_mean),
      Named("collected")=List::create(Named("lo")=FSeq_lo,_["med"]=FSeq_med,_["up"]=FSeq_up,_["mean"]=FSeq_mean),
      Named("first")=List::create(Named("lo")=Ffirst_lo,_["med"]=Ffirst_med,_["up"]=Ffirst_up,_["mean"]=Ffirst_mean),
      Named("all.sub")=List::create(Named("lo")=FSub_all_lo,_["med"]=FSub_all_med,_["up"]=FSub_all_up,_["mean"]=FSub_all_mean),
      Named("all.col")=List::create(Named("lo")=FSeq_all_lo,_["med"]=FSeq_all_med,_["up"]=FSeq_all_up,_["mean"]=FSeq_all_mean),
      Named("col.sub")=List::create(Named("lo")=FSeq_Sub_lo,_["med"]=FSeq_Sub_med,_["up"]=FSeq_Sub_up,_["mean"]=FSeq_Sub_mean),
      Named("all.first")=List::create(Named("lo")=Ffirst_all_lo,_["med"]=Ffirst_all_med,_["up"]=Ffirst_all_up,_["mean"]=Ffirst_all_mean),
      Named("lambda")=List::create(Named("lo")=Lfirst_lo,_["med"]=Lfirst_med,_["up"]=Lfirst_up,_["mean"]=Lfirst_mean),
      Named("alpha")=List::create(Named("lo")=Lalpha_lo,_["med"]=Lalpha_med,_["up"]=Lalpha_up,_["mean"]=Lalpha_mean)
    );

    return(L);
  }



//test

//sampler(1,10,1,0,c(1,1,0,0,0,0,0),c(0.11,30,NA,134,NA,134,1),1,data.london.test$lW,data.london.test$incub,data.london.test$nCountry,data.london.test$Ts, data.london.test$Ti.lo, data.london.test$Ti.up,data.london.test$delta1, data.london.test$tKps,data.london.test$delai.array,c(0.1,8,0.1,8,0.1,8,0.1),data.london.test$T0.max)

//calc_F_country(res.import.london.sub.26.slope1$res,dim(res.import.london.sub.26.slope1$res)[1],data.london.test$lW,data.london.test$nCountry,1,data.london.test$incub, as.matrix(data.london.test$p), data.london.test$tKps,data.london.test$delai.array)

//calc_F_country_auto(res.import.london.sub.26.slope1$res[1:2,],dim(res.import.london.sub.26.slope1$res[1:2,])[1],data.london.test$lW,data.london.test$nCountry,1,data.london.test$incub, as.matrix(data.london.test$p), data.london.test$tKps,data.london.test$delai.array,data.london.test$p.over.R, data.london.test$r)

//auto
//logL_1sub_auto_pois(c(0.11),c(30),1,data.london.test$lW, data.london.test$incub, data.london.test$nCountry, data.london.test$Ts, data.london.test$Ti.lo, data.london.test$Ti.up,data.london.test$delta1,data.london.test$tKps,data.london.test$delai.array,data.london.test$p.over.R,data.london.test$r )

//logL_1sub_auto_pois(c(0.11),c(30),1,data.london.test$lW, data.london.test$incub, data.london.test$nCountry, data.london.test$Ts, data.london.test$Ti.lo, data.london.test$Ti.up,data.london.test$delta1,data.london.test$tKps,data.london.test$delai.array,data.london.test$p.over.R,data.london.test$r)

// logL_1sub_pois(c(0.11),c(30),1.0, 1.0,data.london.test$lW, data.london.test$ahead, data.london.test$incub, data.london.test$nCountry, data.london.test$Ts, data.london.test$Ti.lo, data.london.test$Ti.up,data.london.test$delta1, data.london.test$tKp,data.london.test$s, data.london.test$dt.s.increase,data.london.test$iUK, data.london.test$delai.array,data.london.test$p.over.R,data.london.test$r, 0, 1.0)
